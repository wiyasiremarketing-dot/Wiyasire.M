# Wiyasire Marketing: Web3 Portfolio Website

A single-page marketing portfolio built with **React, Vite, TypeScript and Tailwind CSS**.
It has a hero, services, three clickable concept-project breakdowns, a process timeline, an about section, a lead-magnet form and a contact form.

> **Honesty by design.** The site contains no fake clients, logos, testimonials, statistics or results.
> The three case studies are clearly labelled **"Concept Project — Hypothetical Example"** and use invented products.
> Please keep it that way until you have real, provable work to show.

---

## 1. Run it on your computer

You need **Node.js 18 or newer** (download the "LTS" version from <https://nodejs.org>).

Open a terminal in this folder, then run:

```bash
npm install      # downloads the packages (first time only, takes a minute)
npm run dev      # starts the site
```

Open the address it prints (usually <http://localhost:5173>). The page refreshes automatically when you save a file.

Other useful commands:

| Command | What it does |
| --- | --- |
| `npm run build` | Checks for TypeScript errors, then creates the production site in the `dist/` folder |
| `npm run preview` | Lets you look at the built site locally before publishing |
| `npm run typecheck` | Only checks for TypeScript errors |

---

## 2. Replace the placeholder details (do this before publishing)

**Almost everything personal lives in one file: [`src/config/site.ts`](src/config/site.ts).** Open it; every setting has a comment.

| Setting | What to put there |
| --- | --- |
| `contact.email` | Already set to `wiyasiremarketing@gmail.com` |
| `contact.bookingUrl` | Your Calendly / Cal.com link. Until set, "Book a Discovery Call" scrolls to the contact form |
| `contact.telegramUrl`, `xUrl`, `linkedinUrl` | Telegram and LinkedIn are set; add X if you want it displayed |
| `forms.endpoint` | Your form service URL (see section 3) |
| `forms.leadMagnetSuccess`, `forms.contactSuccess` | The message shown after a successful send. Make sure it matches how you really deliver the checklist |
| `legal.privacyPolicyUrl` | Already set to `/privacy.html`; review the policy before launch |
| `about.founderName`, `founderTitle`, `photoUrl`, `bio` | Your real name, photo and biography (true facts only) |

Anything you leave empty is shown on the page as a clearly marked **"Placeholder"**, never as a fake working link.

**Two more things outside that file:**

1. **`.env`**: set `VITE_SITE_URL` to your real domain (no trailing slash), e.g. `VITE_SITE_URL=https://wiyasire.com`. This fills in the social-sharing preview and the canonical link.
2. **Social image**: `public/og-image.png` is a simple 1200×630 sharing image. Replace it with your own if you like (keep the file name and size).

Your photo goes in the `public/` folder (for example `public/me.jpg`), and then you set `photoUrl: '/me.jpg'`.

### Editing the text

| To change… | Edit this file |
| --- | --- |
| Hero text, problems, process, "why us", about copy, checklist copy | `src/data/content.ts` |
| The four services and the contact-form dropdown | `src/data/services.ts` |
| The three concept projects (all of their text) | `src/data/caseStudies.ts` |
| Colours (accent colour, backgrounds) | `tailwind.config.js` |
| Page title and description for search engines | `index.html` |

When you complete **real** client work, add a new entry to `src/data/caseStudies.ts` and remove the "Concept Project" label for that entry only. Only publish results you can prove and have permission to share.

---

## 3. Connecting the forms (what needs a backend)

A website on its own cannot send email. **Until you connect a service, both forms run in "demo mode"**: they validate the answers, then tell the visitor plainly that nothing was sent, and offer an "email it instead" button. Nothing is ever faked.

**Easiest option: Formspree (free tier available)**

1. Create an account at <https://formspree.io> and make a new form.
2. Copy its endpoint URL (it looks like `https://formspree.io/f/abcdwxyz`).
3. Paste it into `forms.endpoint` in `src/config/site.ts`.
4. Save, redeploy, and send yourself a test message.

Alternatives that work the same way: Netlify Forms (needs small markup changes), Web3Forms, Basin, or your own serverless function. Anything that accepts a JSON `POST` will work with the code in `src/lib/forms.ts`.

**The checklist itself is included.** Download `public/web3-growth-opportunity-checklist.pdf`. Visitors can download it directly from the checklist section. After a successful lead-form submission, the success state also provides a download button. The message does not claim the checklist was emailed automatically.

**Privacy.** A starter privacy notice is available at `public/privacy.html` and the footer links to `/privacy.html`. Review it for your actual setup and applicable Nigerian data-protection obligations before launch, especially after you choose and configure a form provider. Update the policy if you add analytics, cookies, mailing lists, or other processors.

**Your Formspree endpoint is not configured yet.** I have left `forms.endpoint` empty because you have not supplied an actual endpoint. Until you create a Formspree form and paste its real URL into `src/config/site.ts`, submissions stay in demo mode. Do not use a made-up endpoint.

**Never put API keys or secrets in this project.** Everything in a front-end site is public. Form endpoints like Formspree's are safe to include because they are designed to be public; secret API keys are not.

---

## 4. Publish the website

Both options below are free for a site like this.

### Vercel
1. Put this folder on GitHub (create a repository and upload/push the files; `node_modules` and `dist` are already ignored).
2. Sign in at <https://vercel.com> and click **Add New → Project**, then pick the repository.
3. Vercel detects Vite automatically. Leave the defaults (build command `npm run build`, output `dist`) and click **Deploy**.
4. In **Settings → Environment Variables**, add `VITE_SITE_URL` with your final address, then redeploy.
5. Add your own domain in **Settings → Domains**.

### Netlify
1. Put the folder on GitHub as above.
2. At <https://netlify.com> choose **Add new site → Import an existing project**.
3. Build command: `npm run build`. Publish directory: `dist`.
4. Add `VITE_SITE_URL` under **Site configuration → Environment variables**, then redeploy.

*Quick drag-and-drop alternative:* run `npm run build`, then drag the generated `dist` folder onto <https://app.netlify.com/drop>.

No special server settings are needed: the project pages use `#/case/...` addresses, which work on any static host.

---

## 5. How the project is organised

```
index.html              Page title, description, social metadata
.env                    VITE_SITE_URL (your domain)
public/                 favicon.svg, og-image.png, privacy.html, checklist PDF
src/
  config/site.ts        ★ YOUR DETAILS: email, links, form endpoint, bio
  data/                 All the written content (services, case studies, copy)
  components/           One file per page section (Hero, Services, ...)
    ui/                 Reusable pieces: Button, Reveal animation, headings
    forms/              The two forms and their fields
    case/               Layouts used by the project breakdown pages
  pages/                Home page and project-detail page
  hooks/                Small helpers (routing, form state, page title)
  lib/forms.ts          Validation and form sending
  index.css             Global styles, focus ring, reduced-motion handling
```

## 6. Accessibility and performance notes

- Dark theme with high-contrast text, visible keyboard focus rings, a "skip to content" link, semantic headings and landmarks, labelled form fields with announced errors.
- Animations are subtle and switch off automatically for visitors who enable "reduce motion" in their system.
- No images are needed for the design (everything is CSS/SVG), so there are no broken image links and the page loads quickly. Fonts are self-hosted (no external requests).
- Each project page updates the browser tab title and description. Note that this is a client-side single-page app: search engines read the main page well, but individual project pages are not separate crawlable pages. If SEO for each project matters later, the project pages can be moved to a framework with static generation (such as Astro or Next.js).

## 7. Troubleshooting

- **`npm: command not found`**: install Node.js first (see section 1).
- **Blank page or red errors in the terminal**: run `npm run typecheck` and read the first error message; it names the file and line.
- **A placeholder still shows after you edited `site.ts`**: make sure the value is inside the quotes, and that you saved the file.
- **Social preview shows the wrong image**: set `VITE_SITE_URL`, redeploy, then re-scrape the link in the platform's debugger (X, LinkedIn and Facebook all cache previews).
