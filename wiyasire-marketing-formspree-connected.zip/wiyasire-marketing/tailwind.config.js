/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Near-black backgrounds
        ink: {
          950: '#07080a',
          900: '#0b0d10',
          800: '#101319',
          700: '#171b22',
          600: '#222833',
        },
        // The one accent colour. Change it here to re-theme the whole site.
        accent: {
          DEFAULT: '#b8f34f',
          soft: '#d6f994',
          deep: '#8fc92f',
        },
      },
      fontFamily: {
        sans: ['"Inter Variable"', 'Inter', 'system-ui', 'sans-serif'],
        display: ['"Inter Tight Variable"', '"Inter Tight"', 'Inter', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        rail: {
          '0%': { top: '0%', opacity: '0' },
          '10%': { opacity: '1' },
          '90%': { opacity: '1' },
          '100%': { top: '100%', opacity: '0' },
        },
        ring: {
          '0%, 100%': { opacity: '0.35', transform: 'scale(1)' },
          '50%': { opacity: '0.7', transform: 'scale(1.03)' },
        },
      },
      animation: {
        rail: 'rail 5s ease-in-out infinite',
        ring: 'ring 8s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
