/**
 * THE THREE CONCEPT PROJECTS
 *
 * IMPORTANT: Everything in this file is a hypothetical example.
 * The products (Halyard Lend, Kestrel Wallet, Plinth) are invented. They are NOT clients,
 * and no results, metrics, or testimonials are claimed. When you complete real client work,
 * add it as a new entry and remove the "Concept Project" labelling for that entry only.
 */
import type { IconName } from '../components/ui/Icon';

export const CONCEPT_LABEL = 'Concept Project — Hypothetical Example';

export const CONCEPT_DISCLAIMER =
  'This project demonstrates how Wiyasire Marketing approaches Web3 growth problems. The product is fictional. It is not a client engagement, and nothing here is a claim of real work, verified performance, or results.';

// ---------- The building blocks a project page can contain ----------

export type Section =
  | { kind: 'text'; heading: string; paragraphs: string[] }
  | { kind: 'steps'; heading: string; intro?: string; steps: { title: string; text: string }[] }
  | { kind: 'checklist'; heading: string; intro?: string; items: string[] }
  | {
      kind: 'compare';
      heading: string;
      intro?: string;
      rows: { label: string; before: string; after: string }[];
      note?: string;
    }
  | {
      kind: 'calendar';
      heading: string;
      intro?: string;
      days: { day: string; pillar: string; format: string; topic: string; cta: string }[];
    }
  | { kind: 'posts'; heading: string; intro?: string; posts: { day: string; label: string; text: string }[] }
  | { kind: 'pillars'; heading: string; items: { title: string; text: string }[] }
  | {
      kind: 'funnel';
      heading: string;
      intro?: string;
      stages: { stage: string; barrier: string; intervention: string; cta: string; metric: string }[];
    }
  | {
      kind: 'metrics';
      heading: string;
      intro?: string;
      groups: { title: string; items: string[] }[];
      note?: string;
    };

export interface CaseStudy {
  slug: string;
  number: string;
  icon: IconName;
  title: string;
  summary: string;
  tags: string[];
  /** Which little illustration to draw on the card. */
  visual: 'messaging' | 'calendar' | 'funnel';
  product: {
    name: string;
    kind: string;
    description: string;
    audience: string;
  };
  sections: Section[];
}

// ---------- Project 1 ----------

const defiAudit: CaseStudy = {
  slug: 'defi-positioning-audit',
  number: '01',
  icon: 'audit',
  title: 'DeFi Product Positioning and Growth Audit',
  summary:
    'A sample audit of a fictional lending app whose strengths are buried under protocol jargon, with rewritten messaging, a proposed funnel, and the first five actions.',
  tags: ['Positioning', 'Messaging audit', 'Funnel', 'Metrics'],
  visual: 'messaging',
  product: {
    name: 'Halyard Lend (fictional)',
    kind: 'Non-custodial DeFi lending and borrowing app',
    description:
      'A hypothetical app that lets users borrow against their crypto and shows their liquidation risk in plain language before they confirm a position.',
    audience:
      'Primary: people who already hold crypto and borrow occasionally, but worry about liquidation. Secondary: experienced DeFi users comparing lending venues.',
  },
  sections: [
    {
      kind: 'text',
      heading: 'The sample positioning challenge',
      paragraphs: [
        'Imagine Halyard Lend has a well-built product, but its public messaging describes the architecture instead of the benefit. The homepage headline reads: “A modular, isolated-market lending primitive for capital-efficient on-chain credit.”',
        'To an expert, that is accurate. To the person who wants to borrow against their ETH without being liquidated, it says nothing about why this app is safer or clearer than the alternatives.',
        'In this scenario the X bio repeats the same abstract language, the best feature (a plain-language risk explainer) is only mentioned deep in the docs, and community members keep asking the same liquidation questions because the answers are not surfaced anywhere obvious.',
      ],
    },
    {
      kind: 'steps',
      heading: 'How we would audit the public messaging',
      intro: 'A five-part review, using only what any visitor can see.',
      steps: [
        {
          title: 'Messaging inventory',
          text: 'Collect the homepage hero, X bio, pinned post, docs introduction, and any directory listings. Compare how the product is described in each place.',
        },
        {
          title: 'Ten-second clarity test',
          text: 'Check whether a first-time visitor can say who the product is for, what it does, and why it is different, without scrolling.',
        },
        {
          title: 'Funnel walk-through',
          text: 'Follow the journey from an X post to the landing page, to connecting a wallet, to a first position. Note every point of confusion or friction.',
        },
        {
          title: 'Community question review',
          text: 'Read recent community threads to find the questions people repeat. These show where the public messaging is failing.',
        },
        {
          title: 'Competitor positioning map',
          text: 'Compare how three to five comparable protocols describe themselves, and find the positioning space nobody is clearly occupying.',
        },
      ],
    },
    {
      kind: 'compare',
      heading: 'Example positioning improvements',
      intro: 'Sample rewrites that move from describing the architecture to describing the outcome.',
      rows: [
        {
          label: 'Homepage headline',
          before: 'A modular, isolated-market lending primitive for capital-efficient on-chain credit.',
          after: 'Borrow against your crypto and always see how close you are to liquidation.',
        },
        {
          label: 'Supporting line',
          before: 'Permissionless markets with configurable risk parameters.',
          after:
            'Halyard Lend explains your risk in plain language before you confirm, so you borrow with your eyes open.',
        },
        {
          label: 'X bio',
          before: 'Building the credit layer for DeFi.',
          after: 'Non-custodial lending that explains your risk before you confirm.',
        },
        {
          label: 'Primary button',
          before: 'Launch App',
          after: 'Preview your borrowing risk',
        },
      ],
      note: 'Any real rewrite must be checked against what the product actually does. Messaging should never claim more safety than the product can support.',
    },
    {
      kind: 'steps',
      heading: 'Proposed acquisition funnel',
      intro: 'A path that lets people understand the value before they are asked to connect a wallet.',
      steps: [
        {
          title: 'Awareness',
          text: 'Educational X posts about how liquidation works and how to read the warning signs.',
        },
        {
          title: 'Education',
          text: 'A short risk guide that links to a no-wallet risk preview.',
        },
        {
          title: 'Product visit',
          text: 'A landing page built around one action: preview your borrowing risk.',
        },
        {
          title: 'Wallet connection',
          text: 'A clear explanation of what connecting a wallet allows and does not allow.',
        },
        {
          title: 'First position',
          text: 'A guided first borrow with the risk explainer shown at the moment of decision.',
        },
        {
          title: 'Retention',
          text: 'Optional position alerts and a link back to the education content for returning users.',
        },
      ],
    },
    {
      kind: 'steps',
      heading: 'The first five recommended actions',
      steps: [
        {
          title: 'Rewrite the headline and supporting line around the user’s outcome',
          text: 'Test two versions in short conversations with five to ten people who fit the target audience.',
        },
        {
          title: 'Add a no-wallet risk preview to the landing page',
          text: 'Let visitors see the product’s value before they are asked to connect anything.',
        },
        {
          title: 'Turn the most repeated community questions into pinned content',
          text: 'Publish short posts and an FAQ that link to the relevant docs.',
        },
        {
          title: 'Align every public description',
          text: 'Make the X bio, pinned post, website hero, and docs introduction say the same thing in the same words.',
        },
        {
          title: 'Define funnel events and set up tracking before running campaigns',
          text: 'Visit, preview, wallet connection, first position, and return visit, so results can be read honestly.',
        },
      ],
    },
    {
      kind: 'metrics',
      heading: 'Metrics we would track',
      intro: 'No numbers are assumed here. Targets are set with the client against their own baseline.',
      groups: [
        {
          title: 'Attention',
          items: ['Qualified link clicks from X and community channels', 'Profile visits from the target audience'],
        },
        {
          title: 'Understanding',
          items: ['Share of test visitors who can explain the product back in their own words', 'Landing page to risk-preview start rate'],
        },
        {
          title: 'Activation',
          items: ['Wallet connection completion rate', 'Share of connected users who open a first position'],
        },
        {
          title: 'Retention and community',
          items: ['Returning users after 30 days', 'Share of community questions answered by existing content'],
        },
      ],
    },
  ],
};

// ---------- Project 2 ----------

const contentCampaign: CaseStudy = {
  slug: 'seven-day-web3-content-campaign',
  number: '02',
  icon: 'megaphone',
  title: 'Seven-Day Web3 Content Campaign',
  summary:
    'A sample one-week X/Twitter campaign for a fictional wallet, with objectives, content pillars, a day-by-day calendar, three written posts, and a measurement plan.',
  tags: ['Campaign strategy', 'X/Twitter', 'Content pillars', 'CTA strategy'],
  visual: 'calendar',
  product: {
    name: 'Kestrel Wallet (fictional)',
    kind: 'Self-custody Web3 wallet',
    description:
      'A hypothetical wallet whose main feature is a plain-language preview that explains what a transaction or approval will do before the user signs.',
    audience:
      'Primary: people six to twenty-four months into using crypto who still find wallet prompts confusing. Secondary: community moderators and creators who help newcomers.',
  },
  sections: [
    {
      kind: 'text',
      heading: 'Campaign objective',
      paragraphs: [
        'Introduce the transaction-preview feature to self-custody beginners and move interested people from reading about it to trying a demo or joining a waitlist.',
        'The campaign is built to teach first and ask second. Every post has one job and one call to action, so the audience is never asked for something before the post has earned it.',
      ],
    },
    {
      kind: 'pillars',
      heading: 'Content pillars',
      items: [
        {
          title: 'Safety education',
          text: 'Explain what common wallet prompts actually do, in plain language, with no product pitch.',
        },
        {
          title: 'Product in context',
          text: 'Show the preview feature working on a real-world situation rather than listing features.',
        },
        {
          title: 'Builder transparency',
          text: 'Share the thinking behind design decisions to build credibility with careful users.',
        },
        {
          title: 'Community voice',
          text: 'Ask real questions, answer them publicly, and turn them into future content.',
        },
      ],
    },
    {
      kind: 'calendar',
      heading: 'Seven-day X/Twitter content calendar',
      days: [
        {
          day: 'Day 1',
          pillar: 'Safety education',
          format: 'Thread',
          topic: 'What am I actually signing? Three things a wallet request can do.',
          cta: 'Follow for the rest of the week',
        },
        {
          day: 'Day 2',
          pillar: 'Product in context',
          format: 'Short screen recording',
          topic: 'The same transaction shown two ways: raw data versus a plain-language preview.',
          cta: 'Try the interactive demo',
        },
        {
          day: 'Day 3',
          pillar: 'Community voice',
          format: 'Question post',
          topic: 'Which wallet prompt has confused you most?',
          cta: 'Reply with your answer',
        },
        {
          day: 'Day 4',
          pillar: 'Builder transparency',
          format: 'Single post with image',
          topic: 'Why approvals and transfers are shown separately.',
          cta: 'Join the waitlist',
        },
        {
          day: 'Day 5',
          pillar: 'Safety education',
          format: 'Image post',
          topic: 'A short approval-hygiene checklist.',
          cta: 'Save it and share it with a friend',
        },
        {
          day: 'Day 6',
          pillar: 'Community voice',
          format: 'Reply roundup',
          topic: 'You asked, here are the answers to Day 3’s confusing prompts.',
          cta: 'Join the community chat',
        },
        {
          day: 'Day 7',
          pillar: 'Product in context',
          format: 'Recap thread',
          topic: 'Five ideas from the week and where to see the preview in action.',
          cta: 'Try the demo or join the waitlist',
        },
      ],
    },
    {
      kind: 'posts',
      heading: 'Three fully written example posts',
      intro: 'Written in the voice of the fictional brand. Each one stays within the 280-character limit.',
      posts: [
        {
          day: 'Day 1',
          label: 'Safety education opener',
          text:
            'You tap “Confirm” on a wallet prompt. What did you just agree to?\n\nA request can:\n→ send tokens\n→ let a contract spend your tokens later\n→ sign a message that costs nothing but still matters\n\nThe middle one causes the most confusion. A thread:',
        },
        {
          day: 'Day 4',
          label: 'Builder transparency',
          text:
            'A design question we keep debating: should a token approval look like a transfer?\n\nWe say no. A transfer moves tokens now. An approval lets a contract move them later.\n\nSo Kestrel shows them separately, in different words, with the limit first. How would you label it?',
        },
        {
          day: 'Day 7',
          label: 'Recap with conversion step',
          text:
            'This week, in plain language:\n\n1. A signature can be a permission\n2. Approvals are not transfers\n3. Check the spender, not just the app name\n4. A set limit beats “unlimited”\n5. If you cannot explain a prompt, pause\n\nTry the preview demo and tell us what is still unclear.',
        },
      ],
    },
    {
      kind: 'steps',
      heading: 'Call-to-action strategy',
      steps: [
        {
          title: 'One call to action per post',
          text: 'Each post asks for a single, small action so the audience always knows what to do next.',
        },
        {
          title: 'Match the ask to the audience’s readiness',
          text: 'Early posts ask for a follow, save, or reply. The demo and waitlist asks come only after value has been delivered.',
        },
        {
          title: 'Keep links out of the first post of a thread',
          text: 'Education leads. Links to the demo and waitlist appear in later replies and in the recap.',
        },
        {
          title: 'Use trackable links',
          text: 'Add campaign tags to links so demo visits and waitlist sign-ups can be connected back to individual posts.',
        },
      ],
    },
    {
      kind: 'metrics',
      heading: 'How success would be measured',
      intro:
        'The aim is to learn which content moves the right people, not to chase totals. No numbers are assumed; targets are agreed against a real baseline.',
      groups: [
        {
          title: 'Attention quality',
          items: ['Saves and replies from the target audience', 'Follower growth among relevant accounts'],
        },
        {
          title: 'Interest',
          items: ['Click-through to the interactive demo', 'Demo completion rate'],
        },
        {
          title: 'Conversion',
          items: ['Waitlist sign-ups attributed to campaign links', 'Sign-ups by originating post'],
        },
        {
          title: 'Community and learning',
          items: ['Questions captured for future content and docs', 'Which pillar earned the most saves and replies'],
        },
      ],
      note: 'A closing review would recommend which pillars to repeat, which to change, and what to test in the following week.',
    },
  ],
};

// ---------- Project 3 ----------

const acquisitionFunnel: CaseStudy = {
  slug: 'web3-user-acquisition-funnel',
  number: '03',
  icon: 'route',
  title: 'Web3 User Acquisition Funnel',
  summary:
    'A sample user-journey map for a fictional product, from first discovery to retention, with the barrier, the marketing intervention, the call to action, and the metric at each stage.',
  tags: ['User journey', 'Funnel design', 'Onboarding', 'Reporting'],
  visual: 'funnel',
  product: {
    name: 'Plinth (fictional)',
    kind: 'Onchain membership passes for communities',
    description:
      'A hypothetical tool that lets community organisers issue membership passes that members hold in their own wallets, with simple rules for access and events.',
    audience:
      'Community organisers, DAO contributors, and creators who want to manage access and recognise members, many of whom are not deeply technical.',
  },
  sections: [
    {
      kind: 'text',
      heading: 'The journey in one view',
      paragraphs: [
        'This map follows a visitor from first discovery to becoming a returning user. The goal is to find where people are most likely to hesitate and put one clear piece of marketing at each point.',
        'It is a planning model for a fictional product. In a real engagement each stage would be checked against actual analytics, user interviews, and the product itself.',
      ],
    },
    {
      kind: 'funnel',
      heading: 'Discovery to retention',
      stages: [
        {
          stage: 'Discovery',
          barrier: 'Is this relevant to me? I run a community, not a crypto project.',
          intervention:
            'Short X posts and community-builder newsletter placements that explain membership passes using an everyday community example.',
          cta: 'See how a community pass works',
          metric: 'Qualified link clicks from target-audience channels',
        },
        {
          stage: 'Education',
          barrier: 'Do I need a wallet? What does onchain add over a normal membership tool?',
          intervention:
            'A plain-language explainer page and a ninety-second walkthrough, including an honest note on when an onchain pass is not needed.',
          cta: 'Try the sandbox pass builder',
          metric: 'Explainer engagement and click-through to the product',
        },
        {
          stage: 'Product Visit',
          barrier: 'Can I try this without committing, and what will it ask of me?',
          intervention:
            'A focused landing page with one example pass, and a clear statement of what happens at each step.',
          cta: 'Create a test pass',
          metric: 'Landing page to test-pass start rate',
        },
        {
          stage: 'Signup or Wallet Connection',
          barrier: 'I do not have a wallet, or I am nervous about connecting one.',
          intervention:
            'A guided path for people without a wallet, and a short explanation of exactly what permissions are requested.',
          cta: 'Continue with email or connect a wallet',
          metric: 'Connection completion rate and the step where people drop off',
        },
        {
          stage: 'First Meaningful Action',
          barrier: 'I am in. What should I do first?',
          intervention:
            'A short guided checklist: create a pass, set the access rules, invite a few members. Templates are pre-filled.',
          cta: 'Issue your first pass',
          metric: 'Share of new organisers who issue a first pass within seven days',
        },
        {
          stage: 'Retention',
          barrier: 'Why would I come back after the first pass?',
          intervention:
            'Lifecycle messages tied to community events, plus a simple summary of how members are using their passes.',
          cta: 'Plan your next event pass',
          metric: 'Organisers returning after 30 days and organisers who create a second pass',
        },
      ],
    },
    {
      kind: 'checklist',
      heading: 'Where we would look for friction first',
      intro: 'Likely friction points to test, not conclusions about any real product.',
      items: [
        'Jargon on the first screen that assumes the visitor already knows Web3',
        'A wallet-connection request that appears before the product has shown any value',
        'A first task that feels too large, with no template or example to start from',
        'No reason or reminder to return once the first pass is issued',
      ],
    },
    {
      kind: 'steps',
      heading: 'Funnel measurement and reporting plan',
      steps: [
        {
          title: 'Define the funnel events',
          text: 'Landing visit, sandbox start, signup or connection, first pass issued, and second-week return.',
        },
        {
          title: 'Set up tracking before any campaign runs',
          text: 'So every later result has a baseline to compare against.',
        },
        {
          title: 'Review weekly',
          text: 'A short written review: what moved, where people dropped off, and the one change to test next.',
        },
        {
          title: 'Pair numbers with conversations',
          text: 'A handful of short user conversations explains why the numbers look the way they do.',
        },
      ],
    },
  ],
};

export const caseStudies: CaseStudy[] = [defiAudit, contentCampaign, acquisitionFunnel];

export function findCaseStudy(slug: string): CaseStudy | undefined {
  return caseStudies.find((c) => c.slug === slug);
}
