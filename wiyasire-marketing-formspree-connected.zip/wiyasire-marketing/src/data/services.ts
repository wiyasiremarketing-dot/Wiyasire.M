/**
 * The four service offers. Edit the text freely.
 * `id` is used to pre-select the service in the contact form. Keep ids unique.
 * No prices are listed on purpose: every card ends with "Request a Proposal".
 */
import type { IconName } from '../components/ui/Icon';

export interface Service {
  id: string;
  icon: IconName;
  title: string;
  tagline: string;
  whoFor: string;
  problem: string;
  deliverables: string[];
}

export const services: Service[] = [
  {
    id: 'growth-audit',
    icon: 'audit',
    title: 'Web3 Growth Audit',
    tagline: 'A structured review of your public-facing marketing.',
    whoFor:
      'Live or pre-launch projects that suspect their message, content, or onboarding is holding back growth, but are not sure where.',
    problem:
      'Marketing effort is being spent without a clear view of what is working, what is confusing, and what to fix first.',
    deliverables: [
      'Positioning and messaging review',
      'Website and landing-page review',
      'X/Twitter content review',
      'Community and onboarding review',
      'Competitor and positioning observations',
      'Prioritized recommendations',
    ],
  },
  {
    id: 'growth-sprint',
    icon: 'rocket',
    title: 'Web3 Growth Sprint',
    tagline: 'A focused seven-day project that ends with an actionable plan.',
    whoFor:
      'Teams preparing a launch or a relaunch that need a clearer marketing direction quickly, without a long retainer.',
    problem:
      'The team knows it needs to market the product but has no agreed objective, audience, message, or measurement plan.',
    deliverables: [
      'Growth objective and audience definition',
      'Messaging and positioning recommendations',
      'Seven-day content plan',
      'Content examples and creative direction',
      'User-acquisition funnel outline',
      'Relevant partnership and distribution opportunities',
      'Measurement framework',
    ],
  },
  {
    id: 'content-campaign',
    icon: 'megaphone',
    title: 'Web3 Content and Campaign Strategy',
    tagline: 'Campaigns where every post has a job.',
    whoFor:
      'Projects that post regularly but see little connection between content and real outcomes such as sign-ups, product trials, or community activity.',
    problem:
      'Content is produced without a defined objective, so it is hard to tell what to publish next or whether it is working.',
    deliverables: [
      'Campaign messaging',
      'Content pillars',
      'X/Twitter content calendar',
      'Educational and product-focused posts',
      'Community activation ideas',
      'Call-to-action strategy',
      'Campaign tracking sheet',
    ],
  },
  {
    id: 'user-acquisition',
    icon: 'route',
    title: 'User Acquisition and Growth Strategy',
    tagline: 'Map how a stranger becomes an active user.',
    whoFor:
      'Products with attention or a community but a weak path from first visit to first meaningful action.',
    problem:
      'People discover the project but drop off before they understand it, try it, or come back.',
    deliverables: [
      'Target audience and user journey',
      'Funnel analysis',
      'Landing-page messaging recommendations',
      'Onboarding improvement ideas',
      'Distribution channel research',
      'Conversion metrics and reporting plan',
    ],
  },
];

/** Options for the "What are you interested in?" dropdown in the contact form. */
export const serviceOptions: { value: string; label: string }[] = [
  { value: 'discovery-call', label: 'A discovery call' },
  { value: 'mini-audit', label: 'Free Mini Growth Audit' },
  ...services.map((s) => ({ value: s.id, label: s.title })),
  { value: 'not-sure', label: 'Not sure yet' },
];
