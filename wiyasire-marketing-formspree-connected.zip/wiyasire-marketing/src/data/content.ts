/**
 * Website copy for the Problem, Process, Why and About sections.
 * Edit the text here without touching any layout code.
 * Icon names refer to the `iconMap` in src/components/ui/Icon.tsx.
 */
import type { IconName } from '../components/ui/Icon';

export interface TitledItem {
  icon: IconName;
  title: string;
  text: string;
}

export const hero = {
  eyebrow: 'Web3 growth strategy',
  headline: 'Turn Your Web3 Product Into a Growth Engine.',
  subheadline:
    'We help crypto and Web3 teams sharpen their positioning, build meaningful community engagement, and create structured campaigns designed to attract the right users.',
  credibility: ['Positioning', 'Content Strategy', 'Community Growth', 'User Acquisition'],
  positioning:
    'We help Web3 projects turn complex products into clear messaging, stronger communities, and structured user-acquisition campaigns.',
};

export const problems: TitledItem[] = [
  {
    icon: 'message',
    title: 'A strong product with an unclear message',
    text: 'The technology is solid, but a first-time visitor cannot tell what it does or who it is for.',
  },
  {
    icon: 'file',
    title: 'Content without a defined purpose',
    text: 'Posts go out on schedule, yet none is tied to an audience, an objective, or a next step.',
  },
  {
    icon: 'users',
    title: 'Community members who never become users',
    text: 'People join the Discord or Telegram and watch from the sidelines. Nothing guides them into the product.',
  },
  {
    icon: 'route',
    title: 'Marketing disconnected from onboarding',
    text: 'Attention lands on a page or wallet prompt that does not match the promise that earned the click.',
  },
  {
    icon: 'rocket',
    title: 'A launch with no distribution plan',
    text: 'Announcement day happens, but there is no sequence of channels, partners, or follow-up behind it.',
  },
  {
    icon: 'help',
    title: 'Difficulty explaining why anyone should care',
    text: 'The value is real, but it is described in protocol language instead of what the user gets.',
  },
];

export const approach: TitledItem[] = [
  {
    icon: 'compass',
    title: 'Strategy',
    text: 'Define the audience, the objective, and the message before any content is produced.',
  },
  {
    icon: 'file',
    title: 'Content',
    text: 'Create posts, pages, and campaign assets that each have a clear job in the journey.',
  },
  {
    icon: 'network',
    title: 'Distribution',
    text: 'Plan where the right audience already is, and which partners and channels can reach them.',
  },
  {
    icon: 'users',
    title: 'Community activation',
    text: 'Give members a clear path from curiosity to first action, rather than hoping it happens.',
  },
  {
    icon: 'gauge',
    title: 'Measurement',
    text: 'Agree on the metrics up front, review them honestly, and decide the next action from evidence.',
  },
];

export const processSteps = [
  {
    title: 'Discover',
    text: 'Understand the product, audience, goals, and constraints.',
    detail: 'Kick-off questions, product walkthrough, and a clear statement of the objective.',
  },
  {
    title: 'Diagnose',
    text: 'Review positioning, messaging, funnel, and distribution.',
    detail: 'Find where the message, the journey, or the channels are working against each other.',
  },
  {
    title: 'Strategize',
    text: 'Build a prioritized marketing plan.',
    detail: 'Turn findings into a ranked set of actions, owners, and success measures.',
  },
  {
    title: 'Execute',
    text: 'Deliver the agreed campaign assets and activities.',
    detail: 'Produce and ship what was scoped, with clear communication along the way.',
  },
  {
    title: 'Measure and Improve',
    text: 'Review agreed metrics and recommend the next actions.',
    detail: 'Report plainly on what moved, what did not, and what to do next.',
  },
];

export const whyItems: TitledItem[] = [
  {
    icon: 'compass',
    title: 'Strategy before activity',
    text: 'Posting more is not a plan. Every deliverable starts from an audience and an objective.',
  },
  {
    icon: 'target',
    title: 'Marketing tied to business objectives',
    text: 'Work is framed around what the project needs: understanding, activation, or conversion.',
  },
  {
    icon: 'clipboard',
    title: 'Clear deliverables and communication',
    text: 'You know what you are getting, when, and who is responsible for what.',
  },
  {
    icon: 'search',
    title: 'Research-led recommendations',
    text: 'Advice is based on your product, your audience, and your competitors, not a generic template.',
  },
  {
    icon: 'workflow',
    title: 'Practical execution plans',
    text: 'Recommendations come with sequencing and next steps that a small team can act on.',
  },
  {
    icon: 'eye',
    title: 'Transparent reporting',
    text: 'Metrics are agreed in advance and reported honestly, including what did not work.',
  },
];

export const wontDo = [
  'Guarantee token performance, price movement, or exchange listings',
  'Promise a specific number of users, followers, or revenue',
  'Buy fake engagement, bots, or artificial hype',
  'Present marketing as investment advice',
];

export const aboutPrinciples: TitledItem[] = [
  {
    icon: 'message',
    title: 'Explain the value',
    text: 'Translate technical products into plain language that a real user can act on.',
  },
  {
    icon: 'users',
    title: 'Reach the right audience',
    text: 'Focus on the people a product can genuinely help, not on vanity numbers.',
  },
  {
    icon: 'workflow',
    title: 'Build structured systems',
    text: 'Replace scattered marketing activity with a plan that can be measured and improved.',
  },
];

export const leadMagnet = {
  title: 'Free Web3 Growth Opportunity Checklist',
  description:
    'A practical checklist for evaluating a project’s positioning, content, community, and user-acquisition journey. Use it to spot where marketing effort is leaking before you spend more on it.',
  sections: [
    {
      icon: 'compass' as IconName,
      title: 'Positioning',
      example: 'Can a stranger explain what the product does after ten seconds on the homepage?',
    },
    {
      icon: 'file' as IconName,
      title: 'Content',
      example: 'Does each recurring post type have a defined audience and next step?',
    },
    {
      icon: 'users' as IconName,
      title: 'Community',
      example: 'Is there a clear path from joining the community to trying the product?',
    },
    {
      icon: 'route' as IconName,
      title: 'User-acquisition journey',
      example: 'Where do visitors drop off between first click and first meaningful action?',
    },
  ],
};
