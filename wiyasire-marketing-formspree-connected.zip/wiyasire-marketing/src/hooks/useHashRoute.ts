/**
 * A tiny router based on the URL hash, so it works on any static host
 * (Vercel, Netlify, GitHub Pages) with no server configuration.
 *
 *   #/case/some-slug  → a case-study detail page
 *   #services         → the home page, scrolled to the element with id="services"
 *   (empty)           → the home page
 */
import { useEffect, useState } from 'react';

export type Route =
  | { name: 'home'; anchor: string }
  | { name: 'case'; slug: string };

function parseHash(hash: string): Route {
  const clean = hash.replace(/^#/, '');
  if (clean.startsWith('/case/')) {
    const raw = clean.slice('/case/'.length);
    try {
      return { name: 'case', slug: decodeURIComponent(raw) };
    } catch {
      // A malformed address (for example a stray "%") falls back to the raw text, which will show "not found".
      return { name: 'case', slug: raw };
    }
  }
  return { name: 'home', anchor: clean };
}

export function useHashRoute(): Route {
  const [route, setRoute] = useState<Route>(() => parseHash(window.location.hash));

  useEffect(() => {
    const onChange = () => setRoute(parseHash(window.location.hash));
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);

  return route;
}
