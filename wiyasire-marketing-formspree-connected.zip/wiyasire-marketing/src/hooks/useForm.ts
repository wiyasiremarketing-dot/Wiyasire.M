/**
 * Shared form logic for the lead-magnet form and the contact form:
 * field values, validation errors, and submission status.
 */
import { useRef, useState, type FormEvent } from 'react';
import { submitForm, type FormErrors, type FormValues } from '../lib/forms';

export type FormStatus = 'idle' | 'submitting' | 'sent' | 'demo' | 'error';

export function useForm<T extends FormValues>(
  formName: string,
  initialValues: T,
  validate: (values: T) => FormErrors,
) {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<FormStatus>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const formRef = useRef<HTMLFormElement>(null);

  /** Update one field, and clear that field's error as the visitor fixes it. */
  const setField = (name: keyof T & string, value: string) => {
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[name];
        return next;
      });
    }
    if (status !== 'idle' && status !== 'submitting') setStatus('idle');
  };

  const handleSubmit = async (event: FormEvent) => {
    event.preventDefault();
    const found = validate(values);
    if (Object.keys(found).length > 0) {
      setErrors(found);
      setStatus('idle');
      // Move keyboard focus to the first field with a problem.
      requestAnimationFrame(() => {
        formRef.current?.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus();
      });
      return;
    }

    setErrors({});
    setStatus('submitting');
    const result = await submitForm(formName, values);
    if (result.status === 'error') {
      setErrorMessage(result.message);
      setStatus('error');
      return;
    }
    setStatus(result.status);
  };

  const reset = () => {
    setValues(initialValues);
    setErrors({});
    setStatus('idle');
  };

  return { values, errors, status, errorMessage, formRef, setField, handleSubmit, reset };
}
