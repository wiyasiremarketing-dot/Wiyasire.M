/** Updates the browser tab title and meta description when the visible page changes. */
import { useEffect } from 'react';

export const DEFAULT_TITLE = 'Wiyasire Marketing | Web3 Growth Strategy and Marketing';
export const DEFAULT_DESCRIPTION =
  'Wiyasire Marketing helps Web3 and crypto teams sharpen positioning, plan content, activate communities, and build structured user-acquisition campaigns.';

export function usePageMeta(title: string, description: string) {
  useEffect(() => {
    document.title = title;
    const tag = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (tag) tag.setAttribute('content', description);
  }, [title, description]);
}
