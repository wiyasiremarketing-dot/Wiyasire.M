import { useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { CaseStudyNotFound, CaseStudyPage } from './pages/CaseStudyPage';
import { useHashRoute, type Route } from './hooks/useHashRoute';
import { DEFAULT_DESCRIPTION, DEFAULT_TITLE, usePageMeta } from './hooks/usePageMeta';
import { findCaseStudy } from './data/caseStudies';

export default function App() {
  const route = useHashRoute();
  const previous = useRef<Route['name'] | null>(null);

  const study = route.name === 'case' ? findCaseStudy(route.slug) : undefined;

  // Browser tab title + description for the current page.
  usePageMeta(
    study ? `${study.title} | Concept Project | Wiyasire Marketing` : DEFAULT_TITLE,
    study ? study.summary : DEFAULT_DESCRIPTION,
  );

  // Scroll handling when the visible "page" changes.
  useEffect(() => {
    const enteredHome = route.name === 'home' && previous.current !== 'home';

    if (route.name === 'case') {
      window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
    } else if (enteredHome) {
      // Arriving on the home page from a project page, or opening a link like /#services directly.
      const anchor = route.anchor;
      if (anchor && anchor !== 'top') {
        requestAnimationFrame(() => document.getElementById(anchor)?.scrollIntoView());
      } else if (previous.current !== null) {
        window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
      }
    }
    previous.current = route.name;
  }, [route]);

  return (
    <>
      {/* Lets keyboard users skip past the navigation. */}
      <a
        href="#main"
        onClick={(e) => {
          e.preventDefault();
          document.getElementById('main')?.focus();
        }}
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-accent focus:px-4 focus:py-2 focus:font-semibold focus:text-ink-950"
      >
        Skip to main content
      </a>

      <Navbar />

      <main id="main" tabIndex={-1} className="outline-none">
        {route.name === 'case' ? (
          study ? (
            <CaseStudyPage study={study} />
          ) : (
            <CaseStudyNotFound />
          )
        ) : (
          <Home />
        )}
      </main>

      <Footer />
    </>
  );
}
