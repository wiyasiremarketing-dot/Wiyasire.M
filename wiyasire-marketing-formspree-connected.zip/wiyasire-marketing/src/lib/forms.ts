/**
 * Form helpers: validation and submission.
 *
 * HOW SUBMISSION WORKS
 * - If `siteConfig.forms.endpoint` is empty, the forms run in DEMO MODE.
 *   They validate, then tell the visitor honestly that nothing was sent.
 * - If you paste an endpoint (for example from Formspree), the form POSTs JSON to it.
 *   See README → "Connecting the forms".
 */
import { siteConfig } from '../config/site';

export type FormValues = Record<string, string>;
export type FormErrors = Record<string, string>;

export type SubmitResult =
  | { status: 'sent' }
  | { status: 'demo' }
  | { status: 'error'; message: string };

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const HANDLE_RE = /^@[A-Za-z0-9_]{1,15}$/;
const DOMAIN_RE = /^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}(\/\S*)?$/i;

export function isValidEmail(value: string): boolean {
  return EMAIL_RE.test(value.trim());
}

/** Accepts a website (example.com, https://example.com) or an X handle (@name). */
export function isValidWebsiteOrHandle(value: string): boolean {
  const v = value.trim();
  return HANDLE_RE.test(v) || DOMAIN_RE.test(v);
}

export function validateRequired(values: FormValues, field: string, message: string, errors: FormErrors) {
  if (!values[field]?.trim()) errors[field] = message;
}

/** Sends the form to the configured endpoint, or reports demo mode. */
export async function submitForm(formName: string, values: FormValues): Promise<SubmitResult> {
  // Honeypot: real people never fill this hidden field. Bots do. Quietly ignore those.
  if (values.botcheck) return { status: 'sent' };

  const endpoint = siteConfig.forms.endpoint.trim();
  if (!endpoint) return { status: 'demo' };

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ form: formName, ...values }),
    });
    if (response.ok) return { status: 'sent' };
    return {
      status: 'error',
      message: 'The form service rejected the submission. Please try again, or email us directly.',
    };
  } catch {
    return {
      status: 'error',
      message: 'Could not reach the form service. Check your connection and try again, or email us directly.',
    };
  }
}

/** Builds a mailto: link containing what the visitor typed, used as an honest fallback. */
export function buildMailto(subject: string, values: FormValues, labels: Record<string, string>): string {
  const body = Object.entries(labels)
    .map(([key, label]) => `${label}: ${values[key]?.trim() || '-'}`)
    .join('\n');
  return `mailto:${siteConfig.contact.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
