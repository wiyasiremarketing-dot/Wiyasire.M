import { Reveal } from './ui/Reveal';
import { SectionHeading } from './ui/SectionHeading';
import { Icon } from './ui/Icon';
import { aboutPrinciples } from '../data/content';
import { siteConfig } from '../config/site';

export function About() {
  const { founderName, founderTitle, photoUrl, photoAlt, bio } = siteConfig.about;

  return (
    <section id="about" aria-labelledby="about-title" className="section-pad border-t border-white/5">
      <div className="container-x grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        {/* Photo or monogram */}
        <Reveal>
          <div className="mx-auto w-full max-w-xs lg:mx-0">
            <div className="relative aspect-square overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-ink-700 to-ink-900">
              {photoUrl ? (
                <img src={photoUrl} alt={photoAlt || founderName || 'Wiyasire Marketing'} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center" aria-hidden="true">
                  <div className="absolute h-48 w-48 rounded-full bg-accent/10 blur-3xl" />
                  <svg viewBox="0 0 64 64" className="relative h-28 w-28">
                    <path
                      d="M12 18 L22 48 L32 26 L42 48 L52 18"
                      fill="none"
                      stroke="#b8f34f"
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              )}
            </div>
            {(founderName || founderTitle) && (
              <div className="mt-4">
                {founderName && <p className="font-display text-lg font-semibold text-white">{founderName}</p>}
                {founderTitle && <p className="text-sm text-zinc-400">{founderTitle}</p>}
              </div>
            )}
            {/* Visible only while you run the site locally; never shown to visitors. */}
            {import.meta.env.DEV && !photoUrl && (
              <p className="mt-3 rounded-lg border border-dashed border-white/20 p-3 text-xs text-zinc-400">
                Dev hint: add your photo and bio in <code>src/config/site.ts</code> (About section). This note
                does not appear on the published site.
              </p>
            )}
          </div>
        </Reveal>

        <div>
          <Reveal>
            <SectionHeading
              id="about-title"
              eyebrow="About"
              title="Helping Web3 projects explain their value."
            />
          </Reveal>

          <Reveal>
            <div className="mt-6 space-y-4 text-base leading-relaxed text-zinc-300 sm:text-lg">
              <p>
                Wiyasire Marketing is a growth strategy practice for Web3 projects. We help teams explain what they
                have built in plain language, communicate with the audience that can genuinely use it, and replace
                scattered marketing activity with a more structured system.
              </p>
              <p>
                We are early in building our public portfolio. That is why our case studies are clearly labelled
                concept projects, and why we will never claim results or clients we cannot prove.
              </p>
              {bio.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
            </div>
          </Reveal>

          <ul className="mt-10 grid gap-4 sm:grid-cols-3">
            {aboutPrinciples.map((item, i) => (
              <li key={item.title}>
                <Reveal delay={i * 80} className="h-full">
                  <div className="card h-full p-5">
                    <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-accent/10 text-accent">
                      <Icon name={item.icon} className="h-[18px] w-[18px]" />
                    </span>
                    <h3 className="text-base font-semibold">{item.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">{item.text}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
