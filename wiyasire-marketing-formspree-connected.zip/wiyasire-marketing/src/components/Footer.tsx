import { Wordmark } from './Wordmark';
import { navLinks } from './Navbar';
import { isEmailPlaceholder, siteConfig } from '../config/site';

export function Footer() {
  const { email, xUrl, telegramUrl, linkedinUrl } = siteConfig.contact;
  const { privacyPolicyUrl } = siteConfig.legal;
  const socials = [
    { label: 'X', href: xUrl },
    { label: 'Telegram', href: telegramUrl },
    { label: 'LinkedIn', href: linkedinUrl },
  ].filter((s) => s.href);

  return (
    <footer className="border-t border-white/10 bg-ink-950 py-14">
      <div className="container-x">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <a href="#top" aria-label="Wiyasire Marketing, back to top" className="inline-block rounded-lg">
              <Wordmark />
            </a>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-zinc-400">
              Web3 growth strategy: clear messaging, stronger communities, and structured user-acquisition campaigns.
            </p>
          </div>

          <nav aria-label="Footer">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-300">Navigate</p>
            <ul className="space-y-2 text-sm">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-zinc-400 transition-colors hover:text-white">
                    {l.label}
                  </a>
                </li>
              ))}
              <li>
                <a href="#checklist" className="text-zinc-400 transition-colors hover:text-white">
                  Free checklist
                </a>
              </li>
            </ul>
          </nav>

          <div>
            <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-300">Contact</p>
            <ul className="space-y-2 text-sm text-zinc-400">
              <li>
                <a href={`mailto:${email}`} className="transition-colors hover:text-white">
                  {email}
                </a>
                {isEmailPlaceholder && <span className="ml-2 text-xs text-amber-200">(placeholder)</span>}
              </li>
              {socials.map((s) => (
                <li key={s.label}>
                  <a href={s.href} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-white">
                    {s.label}
                  </a>
                </li>
              ))}
              <li>
                {privacyPolicyUrl ? (
                  <a href={privacyPolicyUrl} className="transition-colors hover:text-white">
                    Privacy Policy
                  </a>
                ) : (
                  <span>
                    Privacy Policy <span className="text-xs text-amber-200">(placeholder, not yet published)</span>
                  </span>
                )}
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 space-y-3 border-t border-white/10 pt-6 text-xs leading-relaxed text-zinc-400">
          <p>
            Wiyasire Marketing provides marketing strategy services. Nothing on this site is financial or investment
            advice, and we do not guarantee user growth, token performance, exchange listings, or revenue. Case studies
            on this site are hypothetical concept projects, not client work.
          </p>
          <p>
            &copy; {new Date().getFullYear()} {siteConfig.brand.name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
