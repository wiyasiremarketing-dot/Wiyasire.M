/**
 * The hero illustration: an abstract "growth system" showing how the five parts connect.
 * It is deliberately NOT a dashboard: no numbers, no charts, no live data.
 * Built with plain HTML/CSS and an SVG background, so there is no image file to break.
 */
import { Compass, FileText, Route, Target, Users, type LucideIcon } from 'lucide-react';

const stages: { icon: LucideIcon; title: string; text: string; indent: string }[] = [
  { icon: Compass, title: 'Positioning', text: 'Who it is for and why it matters', indent: 'sm:ml-0' },
  { icon: FileText, title: 'Content', text: 'Messages with a defined job', indent: 'sm:ml-6' },
  { icon: Users, title: 'Community', text: 'Members guided toward action', indent: 'sm:ml-12' },
  { icon: Route, title: 'Onboarding', text: 'A clear path to first use', indent: 'sm:ml-6' },
  { icon: Target, title: 'Conversion', text: 'Measured, then improved', indent: 'sm:ml-0' },
];

export function HeroGraphic() {
  return (
    <figure className="relative mx-auto w-full max-w-md lg:max-w-none">
      <figcaption className="sr-only">
        Diagram of the Wiyasire growth system: positioning leads to content, community, onboarding, and conversion.
      </figcaption>

      {/* Soft glow and concentric rings behind the cards */}
      <div className="pointer-events-none absolute -inset-10" aria-hidden="true">
        <div className="absolute left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/10 blur-[90px]" />
        <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full animate-ring text-white/10" fill="none">
          <circle cx="200" cy="200" r="120" stroke="currentColor" />
          <circle cx="200" cy="200" r="165" stroke="currentColor" strokeDasharray="3 7" />
          <circle cx="200" cy="200" r="195" stroke="currentColor" strokeOpacity="0.5" />
        </svg>
      </div>

      <div className="relative rounded-3xl border border-white/10 bg-gradient-to-b from-ink-700/80 to-ink-900/90 p-5 shadow-2xl shadow-black/50 backdrop-blur sm:p-6">
        <div className="mb-5 flex items-center justify-between">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-zinc-300">The growth system</p>
          <p className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] text-zinc-400">
            Illustrative framework
          </p>
        </div>

        <div className="relative">
          {/* The vertical rail and the small pulse travelling down it */}
          <div className="absolute bottom-6 left-[1.4rem] top-6 w-px bg-gradient-to-b from-accent/60 via-white/15 to-accent/60" aria-hidden="true">
            <span className="absolute left-1/2 h-2.5 w-2.5 -translate-x-1/2 animate-rail rounded-full bg-accent shadow-[0_0_14px_3px_rgba(184,243,79,0.7)]" />
          </div>

          <ol className="relative space-y-3">
            {stages.map(({ icon: IconCmp, title, text, indent }, i) => (
              <li
                key={title}
                className={`flex items-center gap-4 rounded-2xl border border-white/10 bg-ink-900/80 p-3.5 transition-colors hover:border-accent/40 ${indent}`}
              >
                <span className="relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-accent/30 bg-ink-800 text-accent">
                  <IconCmp className="h-5 w-5" aria-hidden="true" strokeWidth={1.75} />
                </span>
                <div className="min-w-0">
                  <p className="font-display text-base font-semibold text-white">
                    <span className="mr-2 text-xs font-medium text-zinc-400" aria-hidden="true">
                      0{i + 1}
                    </span>
                    {title}
                  </p>
                  <p className="text-sm text-zinc-400">{text}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>

        <p className="mt-5 text-center text-xs text-zinc-400">Each stage feeds the next. A gap anywhere weakens the rest.</p>
      </div>
    </figure>
  );
}
