/**
 * Turns one "section" from src/data/caseStudies.ts into its visual layout.
 * To change the text of a project, edit the data file. You rarely need to touch this one.
 */
import { ArrowDown, Check } from 'lucide-react';
import type { Section } from '../../data/caseStudies';

function Heading({ children, intro }: { children: string; intro?: string }) {
  return (
    <>
      <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">{children}</h2>
      {intro && <p className="mt-3 max-w-3xl text-base leading-relaxed text-zinc-400">{intro}</p>}
    </>
  );
}

function Note({ children }: { children: string }) {
  return <p className="mt-5 max-w-3xl text-sm leading-relaxed text-zinc-400">{children}</p>;
}

export function SectionRenderer({ section }: { section: Section }) {
  switch (section.kind) {
    case 'text':
      return (
        <section>
          <Heading>{section.heading}</Heading>
          <div className="mt-4 max-w-3xl space-y-4 text-base leading-relaxed text-zinc-300 sm:text-lg">
            {section.paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
        </section>
      );

    case 'steps':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <ol className="mt-6 space-y-3">
            {section.steps.map((step, i) => (
              <li key={step.title} className="card flex gap-4 p-4 sm:p-5">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-accent/40 bg-accent/10 font-display text-sm font-semibold text-accent">
                  {i + 1}
                </span>
                <div>
                  <h3 className="text-base font-semibold text-white">{step.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-zinc-400">{step.text}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>
      );

    case 'checklist':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <ul className="mt-6 space-y-3">
            {section.items.map((item) => (
              <li key={item} className="flex items-start gap-3 text-zinc-300">
                <Check className="mt-1 h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
                {item}
              </li>
            ))}
          </ul>
        </section>
      );

    case 'compare':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <ul className="mt-6 space-y-4">
            {section.rows.map((row) => (
              <li key={row.label} className="card p-4 sm:p-5">
                <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-zinc-400">{row.label}</p>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="rounded-xl border border-white/10 bg-ink-900/70 p-4">
                    <p className="mb-1 text-xs font-semibold text-zinc-400">Before (hypothetical)</p>
                    <p className="text-sm leading-relaxed text-zinc-400">{row.before}</p>
                  </div>
                  <div className="rounded-xl border border-accent/40 bg-accent/[0.06] p-4">
                    <p className="mb-1 text-xs font-semibold text-accent">After (suggested)</p>
                    <p className="text-sm leading-relaxed text-white">{row.after}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
          {section.note && <Note>{section.note}</Note>}
        </section>
      );

    case 'calendar':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <ol className="mt-6 space-y-3">
            {section.days.map((d) => (
              <li key={d.day} className="card grid gap-3 p-4 sm:p-5 md:grid-cols-[5rem_1fr_14rem] md:items-center md:gap-6">
                <p className="font-display text-xl font-semibold text-accent">{d.day}</p>
                <div>
                  <p className="text-base font-medium leading-snug text-white">{d.topic}</p>
                  <p className="mt-1 text-xs text-zinc-400">
                    {d.pillar} <span aria-hidden="true">&middot;</span>
                    <span className="sr-only">,</span> {d.format}
                  </p>
                </div>
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">Call to action</p>
                  <p className="text-sm text-zinc-200">{d.cta}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>
      );

    case 'posts':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <ul className="mt-6 grid gap-4 lg:grid-cols-3">
            {section.posts.map((post) => (
              <li key={post.day} className="card flex flex-col p-5">
                <p className="text-xs font-semibold uppercase tracking-wider text-accent">
                  {post.day} <span aria-hidden="true">&middot;</span> {post.label}
                </p>
                <blockquote className="mt-4 whitespace-pre-line rounded-xl border border-white/10 bg-ink-900/80 p-4 text-[15px] leading-relaxed text-zinc-100">
                  {post.text}
                </blockquote>
                <p className="mt-3 text-xs text-zinc-400">
                  Example copy &middot; {post.text.length} / 280 characters
                </p>
              </li>
            ))}
          </ul>
        </section>
      );

    case 'pillars':
      return (
        <section>
          <Heading>{section.heading}</Heading>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2">
            {section.items.map((item, i) => (
              <li key={item.title} className="card p-5">
                <p className="text-xs font-semibold text-zinc-400">Pillar {i + 1}</p>
                <h3 className="mt-1 text-lg font-semibold">{item.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">{item.text}</p>
              </li>
            ))}
          </ul>
        </section>
      );

    case 'funnel':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <ol className="mt-6">
            {section.stages.map((s, i) => (
              <li key={s.stage}>
                <div className="card p-5 sm:p-6">
                  <div className="mb-4 flex items-center gap-3">
                    <span className="flex h-8 w-8 items-center justify-center rounded-full border border-accent/40 bg-accent/10 font-display text-sm font-semibold text-accent">
                      {i + 1}
                    </span>
                    <h3 className="text-xl font-semibold">{s.stage}</h3>
                  </div>
                  <dl className="grid gap-4 sm:grid-cols-2">
                    <FunnelField label={'The user’s question or barrier'} text={s.barrier} />
                    <FunnelField label="Marketing intervention" text={s.intervention} />
                    <FunnelField label="Call to action" text={s.cta} highlight />
                    <FunnelField label="Metric to measure" text={s.metric} />
                  </dl>
                </div>
                {i < section.stages.length - 1 && (
                  <div className="flex justify-center py-2 text-zinc-600" aria-hidden="true">
                    <ArrowDown className="h-5 w-5" />
                  </div>
                )}
              </li>
            ))}
          </ol>
        </section>
      );

    case 'metrics':
      return (
        <section>
          <Heading intro={section.intro}>{section.heading}</Heading>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            {section.groups.map((g) => (
              <div key={g.title} className="card p-5">
                <h3 className="text-base font-semibold">{g.title}</h3>
                <ul className="mt-3 space-y-2">
                  {g.items.map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm text-zinc-300">
                      <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-accent" aria-hidden="true" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          {section.note && <Note>{section.note}</Note>}
        </section>
      );
  }
}

function FunnelField({ label, text, highlight }: { label: string; text: string; highlight?: boolean }) {
  return (
    <div className={highlight ? 'rounded-xl border border-accent/30 bg-accent/[0.06] p-3.5' : 'p-0.5'}>
      <dt className={`text-[11px] font-semibold uppercase tracking-wider ${highlight ? 'text-accent' : 'text-zinc-400'}`}>
        {label}
      </dt>
      <dd className="mt-1 text-sm leading-relaxed text-zinc-200">{text}</dd>
    </div>
  );
}
