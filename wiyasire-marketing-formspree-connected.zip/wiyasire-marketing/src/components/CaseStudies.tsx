import { ArrowUpRight } from 'lucide-react';
import { Reveal } from './ui/Reveal';
import { SectionHeading } from './ui/SectionHeading';
import { ConceptBadge } from './ui/ConceptBadge';
import { Icon } from './ui/Icon';
import { caseStudies, type CaseStudy } from '../data/caseStudies';

/** Small abstract illustrations for the top of each card. Pure CSS, no images. */
function CardVisual({ type }: { type: CaseStudy['visual'] }) {
  const shell =
    'relative flex h-40 items-center justify-center overflow-hidden rounded-xl border border-white/10 bg-gradient-to-br from-ink-700 to-ink-900';
  const glow = (
    <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-accent/10 blur-3xl" aria-hidden="true" />
  );

  if (type === 'messaging') {
    return (
      <div className={shell} aria-hidden="true">
        {glow}
        <div className="grid w-4/5 gap-2.5">
          <div className="space-y-1.5 rounded-lg border border-white/10 bg-ink-900/80 p-3 opacity-60">
            <div className="h-1.5 w-11/12 rounded bg-zinc-600" />
            <div className="h-1.5 w-8/12 rounded bg-zinc-600" />
          </div>
          <div className="space-y-1.5 rounded-lg border border-accent/40 bg-ink-900 p-3">
            <div className="h-2 w-7/12 rounded bg-accent" />
            <div className="h-1.5 w-10/12 rounded bg-zinc-400" />
          </div>
        </div>
      </div>
    );
  }

  if (type === 'calendar') {
    return (
      <div className={shell} aria-hidden="true">
        {glow}
        <div className="grid w-4/5 grid-cols-7 gap-1.5">
          {Array.from({ length: 7 }).map((_, i) => (
            <div
              key={i}
              className={`flex h-14 flex-col justify-between rounded-md border p-1.5 ${
                [0, 3, 6].includes(i) ? 'border-accent/40 bg-accent/10' : 'border-white/10 bg-ink-900/80'
              }`}
            >
              <span className="text-[9px] font-semibold text-zinc-400">{i + 1}</span>
              <span className={`h-1 rounded ${[0, 3, 6].includes(i) ? 'bg-accent' : 'bg-zinc-600'}`} />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className={shell} aria-hidden="true">
      {glow}
      <div className="flex w-4/5 flex-col items-center gap-1.5">
        {[100, 82, 64, 48, 34, 22].map((w, i) => (
          <div
            key={w}
            className={`h-3.5 rounded ${i === 5 ? 'bg-accent' : 'bg-white/15'}`}
            style={{ width: `${w}%` }}
          />
        ))}
      </div>
    </div>
  );
}

export function CaseStudies() {
  return (
    <section id="case-studies" aria-labelledby="cases-title" className="section-pad border-t border-white/5">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="cases-title"
            eyebrow="Case studies"
            title="Three concept projects that show how we think."
            description="Wiyasire Marketing is building its public portfolio. Rather than imply client results we cannot verify, these are fully worked, clearly labelled examples of the strategy and deliverables you would receive."
          />
        </Reveal>

        <Reveal>
          <div
            role="note"
            className="mt-8 rounded-xl border border-accent/30 bg-accent/[0.06] p-4 text-sm leading-relaxed text-zinc-300"
          >
            <strong className="font-semibold text-accent">Please note: </strong>
            every project below uses a fictional product. They demonstrate our approach and are not client engagements,
            real results, or verified performance.
          </div>
        </Reveal>

        <div className="mt-10 grid gap-5 lg:grid-cols-3">
          {caseStudies.map((study, i) => (
            <Reveal key={study.slug} delay={i * 90} className="h-full">
              <article className="card card-hover group relative flex h-full flex-col p-5">
                <CardVisual type={study.visual} />

                <div className="mt-5 flex items-center justify-between gap-3">
                  <ConceptBadge />
                </div>

                <div className="mt-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-zinc-400">
                  <Icon name={study.icon} className="h-4 w-4" />
                  Project {study.number}
                </div>

                <h3 className="mt-2 text-xl font-semibold leading-snug">
                  {/* The link is stretched over the whole card so the entire card is clickable. */}
                  <a
                    href={`#/case/${study.slug}`}
                    className="after:absolute after:inset-0 after:rounded-2xl focus-visible:after:outline focus-visible:after:outline-2 focus-visible:after:outline-offset-2 focus-visible:after:outline-accent"
                  >
                    {study.title}
                  </a>
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{study.summary}</p>

                <ul className="mt-4 flex flex-wrap gap-2" aria-label="Topics covered">
                  {study.tags.map((tag) => (
                    <li key={tag} className="rounded-full border border-white/10 px-2.5 py-1 text-xs text-zinc-400">
                      {tag}
                    </li>
                  ))}
                </ul>

                <span className="mt-auto inline-flex items-center gap-1.5 pt-6 text-sm font-semibold text-accent">
                  View project breakdown
                  <ArrowUpRight
                    className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
                    aria-hidden="true"
                  />
                </span>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
