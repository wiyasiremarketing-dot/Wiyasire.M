/**
 * A single labelled form field (text, email, textarea, or select) with accessible error messages.
 */
interface FieldBase {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  required?: boolean;
  hint?: string;
}

type FormFieldProps =
  | (FieldBase & { kind?: 'input'; type?: 'text' | 'email' | 'url'; placeholder?: string; autoComplete?: string })
  | (FieldBase & { kind: 'textarea'; placeholder?: string; rows?: number })
  | (FieldBase & { kind: 'select'; options: { value: string; label: string }[] });

export function FormField(props: FormFieldProps) {
  const { id, label, value, onChange, error, required, hint } = props;
  const describedBy = [hint ? `${id}-hint` : '', error ? `${id}-error` : ''].filter(Boolean).join(' ') || undefined;

  const shared = {
    id,
    name: id,
    value,
    required,
    'aria-invalid': error ? true : undefined,
    'aria-describedby': describedBy,
    className: 'field',
  } as const;

  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-zinc-200">
        {label}
        {required ? (
          <span className="ml-1 text-accent" aria-hidden="true">
            *
          </span>
        ) : (
          <span className="ml-1.5 text-xs font-normal text-zinc-400">(optional)</span>
        )}
      </label>

      {props.kind === 'textarea' ? (
        <textarea
          {...shared}
          rows={props.rows ?? 4}
          placeholder={props.placeholder}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : props.kind === 'select' ? (
        <select {...shared} onChange={(e) => onChange(e.target.value)}>
          {props.options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      ) : (
        <input
          {...shared}
          type={props.type ?? 'text'}
          placeholder={props.placeholder}
          autoComplete={props.autoComplete}
          onChange={(e) => onChange(e.target.value)}
        />
      )}

      {hint && !error && (
        <p id={`${id}-hint`} className="mt-1.5 text-xs text-zinc-400">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-sm text-red-300">
          {error}
        </p>
      )}
    </div>
  );
}
