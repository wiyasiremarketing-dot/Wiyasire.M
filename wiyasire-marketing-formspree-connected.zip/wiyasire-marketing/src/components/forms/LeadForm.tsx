import { Download } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from './FormField';
import { FormFeedback } from './FormFeedback';
import { useForm } from '../../hooks/useForm';
import {
  buildMailto,
  isValidEmail,
  isValidWebsiteOrHandle,
  validateRequired,
  type FormErrors,
} from '../../lib/forms';
import { siteConfig } from '../../config/site';

const initial = { name: '', email: '', project: '', website: '', botcheck: '' };
type Values = typeof initial;

function validate(v: Values): FormErrors {
  const errors: FormErrors = {};
  validateRequired(v, 'name', 'Please enter your name.', errors);
  if (!v.email.trim()) errors.email = 'Please enter your work email.';
  else if (!isValidEmail(v.email)) errors.email = 'That email address does not look right. Please check it.';
  validateRequired(v, 'project', 'Please enter your project name.', errors);
  if (!v.website.trim()) errors.website = 'Please enter your project website or X profile.';
  else if (!isValidWebsiteOrHandle(v.website))
    errors.website = 'Use a website like example.com or an X handle like @yourproject.';
  return errors;
}

export function LeadForm() {
  const { values, errors, status, errorMessage, formRef, setField, handleSubmit } = useForm(
    'lead-magnet',
    initial,
    validate,
  );
  const demoMode = !siteConfig.forms.endpoint.trim();

  const mailto = buildMailto(
    'Free Web3 Growth Opportunity Checklist request',
    values,
    { name: 'Name', email: 'Work email', project: 'Project name', website: 'Project website or X profile' },
  );

  return (
    <form ref={formRef} onSubmit={handleSubmit} noValidate className="card relative space-y-4 p-6 sm:p-8" aria-label="Request the free checklist">
      <FormField id="lead-name" label="Name" value={values.name} onChange={(v) => setField('name', v)} error={errors.name} required autoComplete="name" />
      <FormField id="lead-email" label="Work email" type="email" value={values.email} onChange={(v) => setField('email', v)} error={errors.email} required autoComplete="email" placeholder="you@yourproject.xyz" />
      <FormField id="lead-project" label="Project name" value={values.project} onChange={(v) => setField('project', v)} error={errors.project} required />
      <FormField id="lead-website" label="Project website or X profile" value={values.website} onChange={(v) => setField('website', v)} error={errors.website} required placeholder="yourproject.xyz or @yourproject" />

      {/* Honeypot: hidden from people, visible to simple spam bots. */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label htmlFor="lead-botcheck">Leave this field empty</label>
        <input id="lead-botcheck" name="botcheck" tabIndex={-1} autoComplete="off" value={values.botcheck} onChange={(e) => setField('botcheck', e.target.value)} />
      </div>

      <Button type="submit" size="lg" disabled={status === 'submitting'} className="w-full">
        <Download className="h-4 w-4" aria-hidden="true" />
        {status === 'submitting' ? 'Sending…' : 'Get the Free Checklist'}
      </Button>

      <FormFeedback status={status} errorMessage={errorMessage} successMessage={siteConfig.forms.leadMagnetSuccess} mailtoHref={mailto} successHref="/web3-growth-opportunity-checklist.pdf" successLinkLabel="Download the checklist (PDF)" />

      {demoMode && status === 'idle' && (
        <p className="text-xs leading-relaxed text-zinc-400">
          Demo mode: this form checks your answers but is not connected to an email service yet, so nothing is sent or
          stored.
        </p>
      )}
      <p className="text-xs leading-relaxed text-zinc-400">
        Only share what you are comfortable sharing. We will use your details to respond to this request.
      </p>
    </form>
  );
}
