import { AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { Button } from '../ui/Button';
import type { FormStatus } from '../../hooks/useForm';

interface FormFeedbackProps {
  status: FormStatus;
  errorMessage: string;
  successMessage: string;
  /** A mailto: link containing the visitor's answers, offered in demo mode. */
  mailtoHref: string;
  successHref?: string;
  successLinkLabel?: string;
}

/**
 * Shows the result of a submission.
 * - "sent"  → a success message (only possible once you have connected a real form service)
 * - "demo"  → an honest notice that nothing was delivered, plus a way to email instead
 * - "error" → what went wrong
 */
export function FormFeedback({ status, errorMessage, successMessage, mailtoHref, successHref, successLinkLabel }: FormFeedbackProps) {
  if (status === 'sent') {
    return (
      <div role="status" className="flex gap-3 rounded-xl border border-accent/40 bg-accent/10 p-4 text-sm text-zinc-100">
        <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent" aria-hidden="true" />
        <div className="space-y-3">
          <p>{successMessage}</p>
          {successHref && successLinkLabel && (
            <a href={successHref} download className="inline-flex items-center rounded-lg bg-accent px-4 py-2.5 font-semibold text-ink-950 transition-colors hover:bg-accent-soft">
              {successLinkLabel}
            </a>
          )}
        </div>
      </div>
    );
  }

  if (status === 'demo') {
    return (
      <div role="status" className="rounded-xl border border-amber-300/40 bg-amber-300/10 p-4 text-sm text-zinc-100">
        <p className="flex gap-3">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-amber-300" aria-hidden="true" />
          <span>
            <strong className="font-semibold">Demo mode: nothing was sent.</strong> Your details look valid, but this
            form is not connected to an email service yet, so nothing was saved or delivered.
          </span>
        </p>
        <div className="mt-3 pl-8">
          <Button href={mailtoHref} variant="secondary">
            Send it by email instead
          </Button>
        </div>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div role="alert" className="flex gap-3 rounded-xl border border-red-400/50 bg-red-400/10 p-4 text-sm text-zinc-100">
        <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-300" aria-hidden="true" />
        <p>{errorMessage}</p>
      </div>
    );
  }

  return null;
}
