import { useEffect } from 'react';
import { Send } from 'lucide-react';
import { Button } from '../ui/Button';
import { FormField } from './FormField';
import { FormFeedback } from './FormFeedback';
import { useForm } from '../../hooks/useForm';
import {
  buildMailto,
  isValidEmail,
  isValidWebsiteOrHandle,
  validateRequired,
  type FormErrors,
} from '../../lib/forms';
import { serviceOptions } from '../../data/services';
import { siteConfig } from '../../config/site';

const initial = { name: '', email: '', project: '', website: '', interest: 'discovery-call', message: '', botcheck: '' };
type Values = typeof initial;

function validate(v: Values): FormErrors {
  const errors: FormErrors = {};
  validateRequired(v, 'name', 'Please enter your name.', errors);
  if (!v.email.trim()) errors.email = 'Please enter your work email.';
  else if (!isValidEmail(v.email)) errors.email = 'That email address does not look right. Please check it.';
  validateRequired(v, 'project', 'Please enter your project name.', errors);
  // The website field is optional, but if it is filled in it must look valid.
  if (v.website.trim() && !isValidWebsiteOrHandle(v.website))
    errors.website = 'Use a website like example.com or an X handle like @yourproject.';
  if (!v.message.trim()) errors.message = 'Please tell us a little about your project and goals.';
  else if (v.message.trim().length < 20) errors.message = 'A little more detail helps. Aim for at least a sentence or two.';
  return errors;
}

interface ContactFormProps {
  /**
   * The service chosen by clicking "Request a Proposal" in the services section.
   * `nonce` changes on every click so the same service can be chosen again.
   */
  preselected: { id: string; nonce: number } | null;
}

export function ContactForm({ preselected }: ContactFormProps) {
  const { values, errors, status, errorMessage, formRef, setField, handleSubmit } = useForm(
    'contact',
    initial,
    validate,
  );
  const demoMode = !siteConfig.forms.endpoint.trim();

  // When a visitor clicks a "Request a Proposal" button, pre-select that service.
  useEffect(() => {
    if (preselected) setField('interest', preselected.id);
    // Only re-run when a new click happens (the nonce changes).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preselected?.nonce]);

  const interestLabel = serviceOptions.find((o) => o.value === values.interest)?.label ?? values.interest;
  const mailto = buildMailto(
    `Project enquiry: ${interestLabel}`,
    { ...values, interest: interestLabel },
    {
      name: 'Name',
      email: 'Work email',
      project: 'Project name',
      website: 'Website or X profile',
      interest: 'Interested in',
      message: 'About the project',
    },
  );

  return (
    <form id="contact-form" ref={formRef} onSubmit={handleSubmit} noValidate className="card relative space-y-4 p-6 sm:p-8" aria-label="Contact form">
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField id="contact-name" label="Name" value={values.name} onChange={(v) => setField('name', v)} error={errors.name} required autoComplete="name" />
        <FormField id="contact-email" label="Work email" type="email" value={values.email} onChange={(v) => setField('email', v)} error={errors.email} required autoComplete="email" placeholder="you@yourproject.xyz" />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField id="contact-project" label="Project name" value={values.project} onChange={(v) => setField('project', v)} error={errors.project} required />
        <FormField id="contact-website" label="Website or X profile" value={values.website} onChange={(v) => setField('website', v)} error={errors.website} placeholder="yourproject.xyz or @yourproject" />
      </div>
      <FormField kind="select" id="contact-interest" label="What are you interested in?" value={values.interest} onChange={(v) => setField('interest', v)} options={serviceOptions} required />
      <FormField kind="textarea" id="contact-message" label="Tell us about your project and growth goals" value={values.message} onChange={(v) => setField('message', v)} error={errors.message} required placeholder="What does the product do, who is it for, and what are you trying to achieve?" rows={5} />

      {/* Honeypot: hidden from people, visible to simple spam bots. */}
      <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
        <label htmlFor="contact-botcheck">Leave this field empty</label>
        <input id="contact-botcheck" name="botcheck" tabIndex={-1} autoComplete="off" value={values.botcheck} onChange={(e) => setField('botcheck', e.target.value)} />
      </div>

      <Button type="submit" size="lg" disabled={status === 'submitting'} className="w-full">
        <Send className="h-4 w-4" aria-hidden="true" />
        {status === 'submitting' ? 'Sending…' : "Let's Discuss Your Growth Goals"}
      </Button>

      <FormFeedback status={status} errorMessage={errorMessage} successMessage={siteConfig.forms.contactSuccess} mailtoHref={mailto} />

      {demoMode && status === 'idle' && (
        <p className="text-xs leading-relaxed text-zinc-400">
          Demo mode: this form checks your answers but is not connected to an email service yet, so nothing is sent or
          stored. Use the email address on this page to reach us directly.
        </p>
      )}
      <p className="text-xs leading-relaxed text-zinc-400">
        Only share what you are comfortable sharing. We will use your details to respond to your enquiry.
      </p>
    </form>
  );
}
