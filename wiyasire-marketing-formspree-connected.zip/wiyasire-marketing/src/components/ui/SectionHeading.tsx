import type { ReactNode } from 'react';

interface SectionHeadingProps {
  eyebrow: string;
  title: ReactNode;
  description?: ReactNode;
  align?: 'left' | 'center';
  /** Used to link the section to its heading for screen readers. */
  id?: string;
}

export function SectionHeading({ eyebrow, title, description, align = 'left', id }: SectionHeadingProps) {
  const alignment = align === 'center' ? 'mx-auto text-center' : '';
  return (
    <div className={`max-w-3xl ${alignment}`}>
      <p className="mb-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-accent">
        <span className="h-px w-6 bg-accent/70" aria-hidden="true" />
        {eyebrow}
      </p>
      <h2 id={id} className="text-3xl font-semibold leading-[1.1] tracking-tight sm:text-4xl lg:text-[2.75rem]">
        {title}
      </h2>
      {description && <p className="mt-5 text-base leading-relaxed text-zinc-400 sm:text-lg">{description}</p>}
    </div>
  );
}
