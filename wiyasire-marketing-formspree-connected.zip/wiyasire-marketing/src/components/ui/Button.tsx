/**
 * One button component for the whole site.
 * - Pass `href` to render a link (<a>). External links open in a new tab safely.
 * - Otherwise it renders a real <button>.
 * - variant="primary" is the bright accent button, "secondary" is outlined, "ghost" is text-only.
 */
import type { ReactNode } from 'react';

type Variant = 'primary' | 'secondary' | 'ghost';

interface ButtonProps {
  children: ReactNode;
  variant?: Variant;
  size?: 'md' | 'lg';
  href?: string;
  onClick?: () => void;
  type?: 'button' | 'submit';
  disabled?: boolean;
  className?: string;
  /** Extra text for screen readers when the visible label is not enough. */
  ariaLabel?: string;
}

const base =
  'inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-200 ' +
  'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent ' +
  'disabled:cursor-not-allowed disabled:opacity-60';

const variants: Record<Variant, string> = {
  primary:
    'bg-accent text-ink-950 shadow-[0_0_0_1px_rgba(184,243,79,0.4),0_8px_30px_-8px_rgba(184,243,79,0.45)] hover:bg-accent-soft hover:-translate-y-0.5',
  secondary:
    'border border-white/20 bg-white/[0.03] text-white hover:border-accent/60 hover:bg-white/[0.07] hover:-translate-y-0.5',
  ghost: 'text-zinc-200 hover:text-accent',
};

const sizes = {
  md: 'px-5 py-2.5 text-sm',
  lg: 'px-6 py-3.5 text-base',
};

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  type = 'button',
  disabled,
  className = '',
  ariaLabel,
}: ButtonProps) {
  const classes = `${base} ${variants[variant]} ${sizes[size]} ${className}`;

  if (href !== undefined) {
    const external = /^https?:\/\//i.test(href);
    return (
      <a
        href={href}
        onClick={onClick}
        className={classes}
        aria-label={ariaLabel}
        {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      >
        {children}
      </a>
    );
  }

  return (
    <button type={type} onClick={onClick} disabled={disabled} className={classes} aria-label={ariaLabel}>
      {children}
    </button>
  );
}
