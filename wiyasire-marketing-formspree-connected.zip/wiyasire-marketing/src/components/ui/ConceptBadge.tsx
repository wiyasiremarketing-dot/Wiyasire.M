import { Info } from 'lucide-react';
import { CONCEPT_DISCLAIMER, CONCEPT_LABEL } from '../../data/caseStudies';

/** The prominent "Concept Project — Hypothetical Example" label. */
export function ConceptBadge({ className = '' }: { className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-accent/40 bg-accent/10 px-3 py-1 text-xs font-semibold text-accent ${className}`}
    >
      <Info className="h-3.5 w-3.5" aria-hidden="true" />
      {CONCEPT_LABEL}
    </span>
  );
}

/** The longer disclaimer box shown on the detail pages. */
export function ConceptDisclaimer({ className = '' }: { className?: string }) {
  return (
    <div
      role="note"
      className={`rounded-xl border border-accent/30 bg-accent/[0.06] p-4 text-sm leading-relaxed text-zinc-300 ${className}`}
    >
      <p className="mb-1 font-semibold text-accent">{CONCEPT_LABEL}</p>
      <p>{CONCEPT_DISCLAIMER}</p>
    </div>
  );
}
