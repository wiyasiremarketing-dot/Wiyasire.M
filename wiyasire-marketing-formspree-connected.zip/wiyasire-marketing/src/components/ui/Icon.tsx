/**
 * One place that maps a short icon name (used in the data files) to a Lucide icon.
 * To use a new icon: import it from 'lucide-react', add it to `iconMap`, done.
 */
import {
  BarChart3,
  Check,
  ClipboardCheck,
  Compass,
  Eye,
  FileSearch,
  FileText,
  Gauge,
  HelpCircle,
  Layers,
  LineChart,
  Megaphone,
  MessageSquare,
  Network,
  Rocket,
  Route,
  Search,
  Target,
  Users,
  Workflow,
  type LucideIcon,
} from 'lucide-react';

export const iconMap = {
  chart: BarChart3,
  check: Check,
  clipboard: ClipboardCheck,
  compass: Compass,
  eye: Eye,
  audit: FileSearch,
  file: FileText,
  gauge: Gauge,
  help: HelpCircle,
  layers: Layers,
  growth: LineChart,
  megaphone: Megaphone,
  message: MessageSquare,
  network: Network,
  rocket: Rocket,
  route: Route,
  search: Search,
  target: Target,
  users: Users,
  workflow: Workflow,
} satisfies Record<string, LucideIcon>;

export type IconName = keyof typeof iconMap;

interface IconProps {
  name: IconName;
  className?: string;
}

/** Decorative icon (hidden from screen readers; the surrounding text carries the meaning). */
export function Icon({ name, className = 'h-5 w-5' }: IconProps) {
  const Cmp = iconMap[name];
  return <Cmp className={className} aria-hidden="true" strokeWidth={1.75} />;
}
