import { Reveal } from './ui/Reveal';
import { SectionHeading } from './ui/SectionHeading';
import { Icon } from './ui/Icon';
import { approach, hero, problems } from '../data/content';

export function ProblemSolution() {
  return (
    <section aria-labelledby="problem-title" className="section-pad relative border-t border-white/5">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="problem-title"
            eyebrow="The problem"
            title="Great Web3 products still struggle to be understood."
            description="Marketing is more than posting content. When positioning, distribution, community activation, onboarding, and measurement are not connected, effort leaks out between the gaps."
          />
        </Reveal>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {problems.map((item, i) => (
            <Reveal key={item.title} delay={(i % 3) * 80}>
              <article className="card card-hover h-full p-6">
                <span className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-zinc-200">
                  <Icon name={item.icon} />
                </span>
                <h3 className="text-lg font-semibold leading-snug">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{item.text}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <p className="mt-6 text-sm text-zinc-400">
            Not every project has every one of these problems. A good review finds which ones actually apply, and which
            do not.
          </p>
        </Reveal>

        {/* The approach */}
        <div className="mt-24 rounded-3xl border border-white/10 bg-gradient-to-b from-ink-800/80 to-ink-900/60 p-6 sm:p-10">
          <Reveal>
            <SectionHeading
              eyebrow="How we approach it"
              title="Strategy first. Then content, distribution, community, and measurement."
              description={hero.positioning}
            />
          </Reveal>

          <ol className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            {approach.map((item, i) => (
              <li key={item.title}>
                <Reveal delay={i * 70} className="h-full">
                  <div className="h-full rounded-2xl border border-white/10 bg-ink-900/70 p-5">
                    <div className="mb-4 flex items-center justify-between">
                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent/10 text-accent">
                        <Icon name={item.icon} className="h-[18px] w-[18px]" />
                      </span>
                      <span className="text-xs font-semibold text-zinc-400" aria-hidden="true">
                        0{i + 1}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold">{item.title}</h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">{item.text}</p>
                  </div>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
