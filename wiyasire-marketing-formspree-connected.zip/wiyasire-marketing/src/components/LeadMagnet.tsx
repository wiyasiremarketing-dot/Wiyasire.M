import { ClipboardCheck, Download } from 'lucide-react';
import { Reveal } from './ui/Reveal';
import { Icon } from './ui/Icon';
import { LeadForm } from './forms/LeadForm';
import { leadMagnet } from '../data/content';
import { isEmailPlaceholder, siteConfig } from '../config/site';

export function LeadMagnet() {
  const email = siteConfig.contact.email;

  return (
    <section id="checklist" aria-labelledby="checklist-title" className="section-pad border-t border-white/5">
      <div className="container-x">
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-ink-800 via-ink-900 to-ink-950 p-6 sm:p-10 lg:p-14">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-accent/10 blur-[100px]" aria-hidden="true" />

          <div className="relative grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-14">
            <div>
              <Reveal>
                <p className="mb-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-accent">
                  <ClipboardCheck className="h-4 w-4" aria-hidden="true" />
                  Free resource
                </p>
                <h2 id="checklist-title" className="text-3xl font-semibold leading-[1.1] tracking-tight sm:text-4xl">
                  {leadMagnet.title}
                </h2>
                <p className="mt-5 text-base leading-relaxed text-zinc-300 sm:text-lg">{leadMagnet.description}</p>
              </Reveal>

              <a href="/web3-growth-opportunity-checklist.pdf" download className="mt-6 inline-flex items-center gap-2 rounded-xl border border-accent/40 bg-accent/10 px-4 py-3 text-sm font-semibold text-accent transition-colors hover:bg-accent/15">
                <Download className="h-4 w-4" aria-hidden="true" />
                Download the checklist now (PDF)
              </a>

              <p className="mt-8 text-sm font-semibold uppercase tracking-wider text-zinc-400">What the checklist covers</p>
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                {leadMagnet.sections.map((s, i) => (
                  <li key={s.title}>
                    <Reveal delay={i * 70} className="h-full">
                      <div className="h-full rounded-xl border border-white/10 bg-ink-900/70 p-4">
                        <p className="flex items-center gap-2 font-display text-base font-semibold text-white">
                          <span className="text-accent">
                            <Icon name={s.icon} className="h-4 w-4" />
                          </span>
                          {s.title}
                        </p>
                        <p className="mt-1.5 text-sm leading-relaxed text-zinc-400">Example: {s.example}</p>
                      </div>
                    </Reveal>
                  </li>
                ))}
              </ul>

              <p className="mt-6 text-sm text-zinc-400">
                Prefer email? Write to{' '}
                <a href={`mailto:${email}?subject=Free%20Web3%20Growth%20Opportunity%20Checklist`} className="font-medium text-accent underline underline-offset-4 hover:text-accent-soft">
                  {email}
                </a>
                {isEmailPlaceholder && <span className="ml-1.5 rounded-md bg-white/10 px-1.5 py-0.5 text-xs text-zinc-300">placeholder address</span>}
                .
              </p>
            </div>

            <Reveal>
              <LeadForm />
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
