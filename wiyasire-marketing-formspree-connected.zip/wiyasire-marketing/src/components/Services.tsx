import { ArrowRight, Check } from 'lucide-react';
import { Reveal } from './ui/Reveal';
import { SectionHeading } from './ui/SectionHeading';
import { Button } from './ui/Button';
import { Icon } from './ui/Icon';
import { services } from '../data/services';

interface ServicesProps {
  /** Called when a visitor clicks "Request a Proposal" so the contact form can pre-select the service. */
  onRequestProposal: (serviceId: string) => void;
}

export function Services({ onRequestProposal }: ServicesProps) {
  return (
    <section id="services" aria-labelledby="services-title" className="section-pad border-t border-white/5">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="services-title"
            eyebrow="Services"
            title="Four ways to work together."
            description="Start with a review, a focused sprint, a campaign, or a full acquisition plan. Scope and pricing are agreed on a proposal basis, once we understand your project."
          />
        </Reveal>

        <div className="mt-14 grid gap-5 lg:grid-cols-2">
          {services.map((service, i) => (
            <Reveal key={service.id} delay={(i % 2) * 90} className="h-full">
              <article className="card card-hover flex h-full flex-col p-6 sm:p-8">
                <div className="mb-5 flex items-start justify-between gap-4">
                  <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-accent/30 bg-accent/10 text-accent">
                    <Icon name={service.icon} className="h-6 w-6" />
                  </span>
                  <span className="text-sm font-semibold text-zinc-400" aria-hidden="true">
                    0{i + 1}
                  </span>
                </div>

                <h3 className="text-2xl font-semibold leading-tight">{service.title}</h3>
                <p className="mt-2 text-base text-zinc-300">{service.tagline}</p>

                <dl className="mt-6 space-y-4 text-sm">
                  <div>
                    <dt className="mb-1 text-xs font-semibold uppercase tracking-wider text-accent">Who it is for</dt>
                    <dd className="leading-relaxed text-zinc-400">{service.whoFor}</dd>
                  </div>
                  <div>
                    <dt className="mb-1 text-xs font-semibold uppercase tracking-wider text-accent">
                      The problem it addresses
                    </dt>
                    <dd className="leading-relaxed text-zinc-400">{service.problem}</dd>
                  </div>
                  <div>
                    <dt className="mb-2 text-xs font-semibold uppercase tracking-wider text-accent">What you receive</dt>
                    <dd>
                      <ul className="grid gap-2 sm:grid-cols-1">
                        {service.deliverables.map((d) => (
                          <li key={d} className="flex items-start gap-2.5 text-zinc-300">
                            <Check className="mt-0.5 h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
                            {d}
                          </li>
                        ))}
                      </ul>
                    </dd>
                  </div>
                </dl>

                <div className="mt-auto pt-8">
                  <Button
                    variant="secondary"
                    onClick={() => onRequestProposal(service.id)}
                    ariaLabel={`Request a proposal for ${service.title}`}
                  >
                    Request a Proposal
                    <ArrowRight className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        {/* Free mini audit strip */}
        <Reveal>
          <div className="mt-6 flex flex-col items-start justify-between gap-5 rounded-2xl border border-accent/30 bg-accent/[0.06] p-6 sm:flex-row sm:items-center sm:p-8">
            <div className="max-w-2xl">
              <h3 className="text-xl font-semibold">Not sure where to start?</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-zinc-300">
                Request a free mini growth audit: a short, focused look at one part of your public-facing marketing,
                with a few practical observations.
              </p>
            </div>
            <Button onClick={() => onRequestProposal('mini-audit')} className="shrink-0">
              Request a Free Mini Growth Audit
            </Button>
          </div>
        </Reveal>

        <p className="mt-6 max-w-3xl text-sm leading-relaxed text-zinc-400">
          Marketing strategy supports growth; it does not guarantee it. Results depend on the product, the market, and
          execution on both sides. We do not guarantee user numbers, token performance, exchange listings, or revenue.
        </p>
      </div>
    </section>
  );
}
