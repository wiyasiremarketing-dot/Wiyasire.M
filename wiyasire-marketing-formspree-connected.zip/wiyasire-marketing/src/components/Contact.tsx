import { AtSign, CalendarCheck, Linkedin, Mail, Send, type LucideIcon } from 'lucide-react';
import { Reveal } from './ui/Reveal';
import { ContactForm } from './forms/ContactForm';
import { bookingHref, hasBookingUrl, isEmailPlaceholder, siteConfig } from '../config/site';

interface ContactMethodProps {
  icon: LucideIcon;
  label: string;
  /** What to show as the link text when a real URL is set. */
  value: string;
  href: string;
  /** True when the value has not been replaced with a real one yet. */
  placeholder: boolean;
  placeholderHint: string;
}

/** One contact option. Real values are links. Missing values are shown as a clearly marked placeholder. */
function ContactMethod({ icon: IconCmp, label, value, href, placeholder, placeholderHint }: ContactMethodProps) {
  const external = /^https?:\/\//i.test(href);
  const content = (
    <>
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-accent">
        <IconCmp className="h-5 w-5" aria-hidden="true" strokeWidth={1.75} />
      </span>
      <span className="min-w-0">
        <span className="flex flex-wrap items-center gap-2 text-sm font-semibold text-white">
          {label}
          {placeholder && (
            <span className="rounded-md bg-amber-300/15 px-1.5 py-0.5 text-[11px] font-medium text-amber-200">
              Placeholder
            </span>
          )}
        </span>
        <span className="block break-words text-sm text-zinc-400">{placeholder ? placeholderHint : value}</span>
      </span>
    </>
  );

  // An unset method is not clickable, so it can never lead to a fake destination.
  if (!href) {
    return <li className="flex items-center gap-3 rounded-xl border border-dashed border-white/15 p-3">{content}</li>;
  }
  return (
    <li>
      <a
        href={href}
        className="flex items-center gap-3 rounded-xl border border-white/10 p-3 transition-colors hover:border-accent/40 hover:bg-white/[0.03]"
        {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      >
        {content}
      </a>
    </li>
  );
}

interface ContactProps {
  preselected: { id: string; nonce: number } | null;
}

export function Contact({ preselected }: ContactProps) {
  const { email, telegramUrl, xUrl, linkedinUrl } = siteConfig.contact;

  return (
    <section id="contact" aria-labelledby="contact-title" className="section-pad border-t border-white/5">
      <div className="container-x grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <div>
          <Reveal>
            <p className="mb-4 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-accent">
              <span className="h-px w-6 bg-accent/70" aria-hidden="true" />
              Contact
            </p>
            <h2 id="contact-title" className="text-3xl font-semibold leading-[1.1] tracking-tight sm:text-4xl lg:text-[2.75rem]">
              Let&rsquo;s Discuss Your Growth Goals.
            </h2>
            <p className="mt-5 text-base leading-relaxed text-zinc-400 sm:text-lg">
              Tell us about your project, where it is today, and what you want it to achieve. We will review your
              message and reply with next steps, whether that is a discovery call, a free mini growth audit, or a
              proposal.
            </p>
          </Reveal>

          <Reveal>
            <ul className="mt-8 space-y-3">
              <ContactMethod
                icon={Mail}
                label="Email"
                value={email}
                href={`mailto:${email}`}
                placeholder={isEmailPlaceholder}
                placeholderHint={email}
              />
              <ContactMethod
                icon={CalendarCheck}
                label="Book a discovery call"
                value="Pick a time that suits you"
                href={bookingHref}
                placeholder={!hasBookingUrl}
                placeholderHint="Scroll to the contact form to arrange a call"
              />
              <ContactMethod
                icon={Send}
                label="Telegram"
                value="Message on Telegram"
                href={telegramUrl}
                placeholder={!telegramUrl}
                placeholderHint="Telegram link not added yet"
              />
              <ContactMethod
                icon={AtSign}
                label="X (Twitter)"
                value="Follow and message on X"
                href={xUrl}
                placeholder={!xUrl}
                placeholderHint="X profile link not added yet"
              />
              <ContactMethod
                icon={Linkedin}
                label="LinkedIn"
                value="Connect on LinkedIn"
                href={linkedinUrl}
                placeholder={!linkedinUrl}
                placeholderHint="LinkedIn link not added yet"
              />
            </ul>
          </Reveal>
        </div>

        <Reveal>
          <ContactForm preselected={preselected} />
        </Reveal>
      </div>
    </section>
  );
}
