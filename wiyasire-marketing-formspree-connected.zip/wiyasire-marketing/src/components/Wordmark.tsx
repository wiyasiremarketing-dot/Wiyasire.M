import { siteConfig } from '../config/site';

/** The Wiyasire Marketing logo: a small "W" mark plus the wordmark. Pure SVG + text, no image file. */
export function Wordmark({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      <svg viewBox="0 0 64 64" className="h-8 w-8" aria-hidden="true">
        <rect width="64" height="64" rx="14" fill="#0b0d10" />
        <rect x="1" y="1" width="62" height="62" rx="13" fill="none" stroke="#b8f34f" strokeOpacity="0.4" strokeWidth="2" />
        <path
          d="M14 20 L23 46 L32 28 L41 46 L50 20"
          fill="none"
          stroke="#b8f34f"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
      <span className="font-display text-lg font-semibold tracking-tight text-white">
        {siteConfig.brand.shortName}
        <span className="font-normal text-zinc-400"> Marketing</span>
      </span>
    </span>
  );
}
