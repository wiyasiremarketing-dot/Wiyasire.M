import { Ban } from 'lucide-react';
import { Reveal } from './ui/Reveal';
import { SectionHeading } from './ui/SectionHeading';
import { Icon } from './ui/Icon';
import { whyItems, wontDo } from '../data/content';

export function WhyUs() {
  return (
    <section aria-labelledby="why-title" className="section-pad border-t border-white/5">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="why-title"
            eyebrow="Why Wiyasire Marketing"
            title="Practical, honest growth strategy."
            description="No inflated promises. A clear way of working that treats marketing as part of the product journey."
          />
        </Reveal>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {whyItems.map((item, i) => (
            <Reveal key={item.title} delay={(i % 3) * 80} className="h-full">
              <article className="card h-full p-6">
                <span className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-accent/10 text-accent">
                  <Icon name={item.icon} />
                </span>
                <h3 className="text-lg font-semibold leading-snug">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{item.text}</p>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="mt-6 rounded-2xl border border-white/10 bg-gradient-to-br from-ink-800 to-ink-900 p-6 sm:p-8">
            <h3 className="flex items-center gap-2.5 text-lg font-semibold">
              <Ban className="h-5 w-5 text-accent" aria-hidden="true" />
              What we will not do
            </h3>
            <ul className="mt-4 grid gap-x-8 gap-y-2.5 text-sm text-zinc-300 sm:grid-cols-2">
              {wontDo.map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <span className="mt-2 h-1 w-1 shrink-0 rounded-full bg-accent" aria-hidden="true" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
