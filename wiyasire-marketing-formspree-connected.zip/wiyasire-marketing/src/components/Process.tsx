import { Reveal } from './ui/Reveal';
import { SectionHeading } from './ui/SectionHeading';
import { processSteps } from '../data/content';

export function Process() {
  return (
    <section id="process" aria-labelledby="process-title" className="section-pad border-t border-white/5">
      <div className="container-x">
        <Reveal>
          <SectionHeading
            id="process-title"
            eyebrow="Our process"
            title="A simple five-step workflow."
            description="Every engagement follows the same path from understanding the project to improving it, so you always know where we are and what comes next."
          />
        </Reveal>

        {/* Vertical timeline on mobile, horizontal on large screens */}
        <ol className="relative mt-14 grid gap-8 lg:grid-cols-5 lg:gap-5">
          {/* Connecting line (desktop) */}
          <div
            className="pointer-events-none absolute left-0 right-0 top-5 hidden h-px bg-gradient-to-r from-transparent via-white/20 to-transparent lg:block"
            aria-hidden="true"
          />
          {/* Connecting line (mobile) */}
          <div
            className="pointer-events-none absolute bottom-4 left-5 top-4 w-px bg-gradient-to-b from-accent/50 via-white/15 to-transparent lg:hidden"
            aria-hidden="true"
          />

          {processSteps.map((step, i) => (
            <li key={step.title} className="relative pl-16 lg:pl-0">
              <Reveal delay={i * 90}>
                <span className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-full border border-accent/50 bg-ink-950 font-display text-sm font-semibold text-accent lg:relative lg:mb-6">
                  {i + 1}
                </span>
                <h3 className="text-xl font-semibold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-300">{step.text}</p>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{step.detail}</p>
              </Reveal>
            </li>
          ))}
        </ol>

        <Reveal>
          <div className="mt-14 rounded-2xl border border-white/10 bg-ink-800/70 p-6 text-sm leading-relaxed text-zinc-300 sm:p-8 sm:text-base">
            <p className="font-semibold text-white">Agreed before work begins.</p>
            <p className="mt-1.5 text-zinc-400">
              Scope, deliverables, responsibilities, and reporting are agreed with you before any work starts, so
              expectations on both sides are clear from day one.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
