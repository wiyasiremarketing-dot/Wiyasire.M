import { ArrowRight } from 'lucide-react';
import { Button } from './ui/Button';
import { HeroGraphic } from './HeroGraphic';
import { hero } from '../data/content';
import { bookingHref } from '../config/site';

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative overflow-hidden pb-20 pt-32 sm:pb-28 sm:pt-40">
      {/* Background: dotted grid + one soft accent glow */}
      <div className="bg-grid pointer-events-none absolute inset-0" aria-hidden="true" />
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[28rem] w-[60rem] -translate-x-1/2 rounded-full bg-accent/[0.07] blur-[120px]"
        aria-hidden="true"
      />

      <div className="container-x relative grid items-center gap-14 lg:grid-cols-[1.1fr_0.9fr] lg:gap-10">
        <div>
          <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/[0.04] px-3.5 py-1.5 text-xs font-medium text-zinc-200">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" aria-hidden="true" />
            {hero.eyebrow}
          </p>

          <h1
            id="hero-title"
            className="text-[2.6rem] font-semibold leading-[1.04] tracking-tight sm:text-6xl lg:text-[4.1rem]"
          >
            Turn Your Web3 Product Into a{' '}
            <span className="bg-gradient-to-r from-accent via-accent-soft to-accent bg-clip-text text-transparent">
              Growth Engine.
            </span>
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-zinc-300 sm:text-xl">{hero.subheadline}</p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <Button href={bookingHref} size="lg">
              Book a Discovery Call
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Button href="#case-studies" variant="secondary" size="lg">
              Explore Our Work
            </Button>
          </div>

          <ul
            aria-label="What we focus on"
            className="mt-10 flex flex-wrap items-center gap-x-3 gap-y-2 text-sm font-medium text-zinc-300"
          >
            {hero.credibility.map((item, i) => (
              <li key={item} className="flex items-center gap-3">
                {i > 0 && (
                  <span className="text-accent" aria-hidden="true">
                    &bull;
                  </span>
                )}
                {item}
              </li>
            ))}
          </ul>
        </div>

        <HeroGraphic />
      </div>
    </section>
  );
}
