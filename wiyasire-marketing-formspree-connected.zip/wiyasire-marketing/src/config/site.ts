/**
 * ============================================================
 *  SITE CONFIGURATION: THE ONE FILE YOU EDIT FOR YOUR DETAILS
 * ============================================================
 *
 * Everything personal to you lives here: email, booking link, social links,
 * your biography and photo, and the form connection.
 *
 * - Leave a value as "" (empty quotes) if you don't have it yet. The site will
 *   show a clearly marked "Placeholder" instead of a broken or fake link.
 * - Save the file and the site updates automatically while `npm run dev` is running.
 */

export const siteConfig = {
  // ---------- Brand ----------
  brand: {
    name: 'Wiyasire Marketing',
    // Short name used in tight spaces.
    shortName: 'Wiyasire',
  },

  // ---------- Contact details ----------
  contact: {
    // 1) Public contact email shown across the website.
    email: 'wiyasiremarketing@gmail.com',

    // 2) BOOKING LINK (Calendly, Cal.com, SavvyCal, etc.).
    //    Example: 'https://calendly.com/your-name/discovery-call'
    //    If empty, every "Book a Discovery Call" button scrolls to the contact form instead.
    bookingUrl: '',

    // 3) OPTIONAL social / messaging links. Leave empty until you have them.
    //    Telegram example: 'https://t.me/your_username'
    telegramUrl: 'https://t.me/Wiyasire01',
    //    X (Twitter) example: 'https://x.com/your_handle'
    xUrl: '',
    //    LinkedIn example: 'https://www.linkedin.com/in/your-name'
    linkedinUrl: 'https://www.linkedin.com/in/sani-hamza-8b944725b?utm_source=share_via&utm_content=profile&utm_medium=member_android',
  },

  // ---------- Forms ----------
  // The lead-magnet form and contact form need a service to receive submissions,
  // because a website alone can't send email. See README → "Connecting the forms".
  forms: {
    // Paste your form endpoint here, e.g. a Formspree URL: 'https://formspree.io/f/xxxxxxxx'
    // While this is empty the forms run in DEMO MODE: they validate input but
    // do NOT send or store anything, and they say so clearly to the visitor.
    endpoint: 'https://formspree.io/f/xnppjjle',

    // Shown after a successful lead-magnet submission (only appears when the endpoint above is set).
    // Change this so it matches how you really deliver the checklist.
    leadMagnetSuccess:
      'Thanks — your request was received. You can download the Web3 Growth Opportunity Checklist directly using the link below.',

    // Shown after a successful contact-form submission.
    contactSuccess:
      'Message received. We will review your project details and reply with next steps.',
  },

  // ---------- Legal ----------
  legal: {
    // Public privacy notice included at /privacy.html. Review it for your actual setup before launch.
    privacyPolicyUrl: '/privacy.html',
  },

  // ---------- About section: add your real details here ----------
  about: {
    // Founder name and title displayed in the About section.
    founderName: 'Hamza Sain Onimisi',
    founderTitle: 'Marketing Strategist & Founder of Wiyasire Marketing',

    // Your photo. Put the image file in the /public folder (for example /public/me.jpg)
    // and set this to '/me.jpg'. Leave empty to show the Wiyasire monogram instead.
    photoUrl: '',
    photoAlt: '',

    // Biography copy: keep it accurate and update it as your experience grows.
    bio: [
      'I am Hamza Sain Onimisi, a marketing professional building Wiyasire Marketing around a practical belief: good marketing should connect a clear message to a real audience and a measurable next step.',
      'My work and learning focus on digital marketing, social media strategy, content planning, audience research, customer journeys, and helping businesses communicate their value more clearly. I have also been developing marketing resources and strategy frameworks for small businesses.',
      'Wiyasire Marketing is now focused on applying that strategic approach to Web3 and crypto products: simplifying complex ideas, planning useful content, mapping user-acquisition journeys, and identifying realistic distribution opportunities. The portfolio includes clearly labelled concept projects to demonstrate my thinking; they are not presented as client engagements or verified results.',
      'I value honest communication, clear deliverables, consistent execution, and learning from evidence. I do not promise guaranteed growth, token performance, or revenue. My goal is to help teams make their marketing more focused, understandable, and actionable.',
    ],
  },
};

// ---------- Helpers (you don't need to edit anything below) ----------

/** True while the email is still the placeholder address. */
export const isEmailPlaceholder = siteConfig.contact.email.endsWith('@your-domain.com');

/** Where "Book a Discovery Call" buttons point. Falls back to the contact form. */
export const bookingHref = siteConfig.contact.bookingUrl.trim() || '#contact-form';

/** True if the booking link is a real external URL. */
export const hasBookingUrl = siteConfig.contact.bookingUrl.trim().length > 0;
