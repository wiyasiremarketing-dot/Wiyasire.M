import { ArrowLeft, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { ConceptBadge, ConceptDisclaimer } from '../components/ui/ConceptBadge';
import { SectionRenderer } from '../components/case/SectionRenderer';
import { caseStudies, type CaseStudy } from '../data/caseStudies';
import { bookingHref } from '../config/site';

/** A full breakdown page for one concept project. */
export function CaseStudyPage({ study }: { study: CaseStudy }) {
  const others = caseStudies.filter((c) => c.slug !== study.slug);

  return (
    <article className="pb-24 pt-28 sm:pt-36">
      <div className="container-x max-w-4xl">
        <a
          href="#case-studies"
          className="inline-flex items-center gap-2 rounded-lg text-sm font-medium text-zinc-300 transition-colors hover:text-accent"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          Back to case studies
        </a>

        <header className="mt-8">
          <ConceptBadge />
          <h1 className="mt-5 text-4xl font-semibold leading-[1.08] tracking-tight sm:text-5xl">{study.title}</h1>
          <p className="mt-5 max-w-3xl text-lg leading-relaxed text-zinc-300">{study.summary}</p>
        </header>

        <ConceptDisclaimer className="mt-8" />

        {/* Facts about the fictional product */}
        <section aria-label="About the fictional product" className="card mt-8 grid gap-6 p-6 sm:p-8 md:grid-cols-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-accent">Hypothetical product</p>
            <p className="mt-1.5 font-display text-xl font-semibold text-white">{study.product.name}</p>
            <p className="mt-1 text-sm text-zinc-400">{study.product.kind}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-accent">What it does</p>
            <p className="mt-1.5 text-sm leading-relaxed text-zinc-300">{study.product.description}</p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-accent">Target audience</p>
            <p className="mt-1.5 text-sm leading-relaxed text-zinc-300">{study.product.audience}</p>
          </div>
        </section>

        <div className="mt-16 space-y-16">
          {study.sections.map((section) => (
            <SectionRenderer key={section.heading} section={section} />
          ))}
        </div>

        {/* What next */}
        <aside className="mt-20 rounded-3xl border border-accent/30 bg-gradient-to-br from-accent/[0.09] to-transparent p-7 sm:p-10">
          <h2 className="text-2xl font-semibold sm:text-3xl">Want this kind of thinking applied to your project?</h2>
          <p className="mt-3 max-w-2xl text-base leading-relaxed text-zinc-300">
            This was a concept project. A real engagement starts with your product, your audience, and your goals.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button href={bookingHref} size="lg">
              Book a Discovery Call
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Button>
            <Button href="#contact" variant="secondary" size="lg">
              Request a Free Mini Growth Audit
            </Button>
          </div>
        </aside>

        <nav aria-label="Other concept projects" className="mt-14">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-400">More concept projects</h2>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {others.map((o) => (
              <li key={o.slug}>
                <a href={`#/case/${o.slug}`} className="card card-hover block p-5">
                  <p className="text-xs font-semibold text-zinc-400">Project {o.number}</p>
                  <p className="mt-1 font-display text-lg font-semibold text-white">{o.title}</p>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </article>
  );
}

/** Shown if someone opens a project address that does not exist. */
export function CaseStudyNotFound() {
  return (
    <div className="container-x pb-24 pt-36 text-center">
      <h1 className="text-4xl font-semibold">Project not found</h1>
      <p className="mx-auto mt-4 max-w-md text-zinc-400">That project page does not exist. You can browse all concept projects instead.</p>
      <div className="mt-8">
        <Button href="#case-studies">Back to case studies</Button>
      </div>
    </div>
  );
}
