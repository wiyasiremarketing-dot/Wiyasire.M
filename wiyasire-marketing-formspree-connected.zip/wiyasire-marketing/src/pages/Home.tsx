import { useState } from 'react';
import { Hero } from '../components/Hero';
import { ProblemSolution } from '../components/ProblemSolution';
import { Services } from '../components/Services';
import { CaseStudies } from '../components/CaseStudies';
import { Process } from '../components/Process';
import { WhyUs } from '../components/WhyUs';
import { About } from '../components/About';
import { LeadMagnet } from '../components/LeadMagnet';
import { Contact } from '../components/Contact';

/** The single-page home: every section in order. */
export function Home() {
  // Remembers which service a visitor asked about, so the contact form can pre-select it.
  const [preselected, setPreselected] = useState<{ id: string; nonce: number } | null>(null);

  const handleRequestProposal = (serviceId: string) => {
    setPreselected({ id: serviceId, nonce: Date.now() });
    document.getElementById('contact')?.scrollIntoView();
    window.history.replaceState(null, '', '#contact');
  };

  return (
    <div id="top">
      <Hero />
      <ProblemSolution />
      <Services onRequestProposal={handleRequestProposal} />
      <CaseStudies />
      <Process />
      <WhyUs />
      <About />
      <LeadMagnet />
      <Contact preselected={preselected} />
    </div>
  );
}
